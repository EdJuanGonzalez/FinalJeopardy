import java.util.Comparator;
class PlayerPositionComparator implements Comparator<Player> {
    @Override
    public int compare(Player player1, Player player2) {
        // Compare players based on their position field
        return Integer.compare(player1.getPosition(), player2.getPosition());
    }
}