public class Anime {
    private String name;
    private String attribute;

    public Anime(String name, String releaseYear) {
        this.name = name;
        this.attribute = releaseYear;
    }

    //setters

    public void setName(String name) {
        this.name = name;
    }

    public void setAttribute(String releaseYear) {
        this.attribute = releaseYear;
    }

    //getters

    public String getName() {
        return this.name;
    }

    public String getAttribute() {
        return this.attribute;
    }

    //to String

    public String toString() {
        return "Name: " + this.name + " Release Year: " + this.attribute;
    }
}
