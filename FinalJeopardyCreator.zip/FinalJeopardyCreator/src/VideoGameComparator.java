import java.util.Comparator;

public class VideoGameComparator implements Comparator<VideoGame> {
    @Override
    public int compare(VideoGame videoGame1, VideoGame videoGame2) {
        // Compare characters based on their rank field
        return Integer.compare(videoGame1.getRank(), videoGame2.getRank());
    }
}
