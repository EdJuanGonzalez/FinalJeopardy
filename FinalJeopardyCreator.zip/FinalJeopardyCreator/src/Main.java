import java.util.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

//What the program is
/*
This program is used to design a final jeopardy question and keep track of things that may be lost to the mind of the host
Note: Currently there is no reason for placement, however I will not remove it because in the future it may be used to
provide higher placing players with benefits
*/

//Notes
/*
Note: If you want to use a txt file to input correct answers, then make sure the txt file is in resources folder

Note: If you are using the program for your own jeopardy, Do not show participants your screen until all
participants and all Object used as correct answers are inputted

Note: Java 8 required to run code

Note: Host using this program,
Make sure that the guesses you inputted match whatever you inputted for your correct answers
not case-sensitive

What you do need to look out for is things such as abbreviations
For example if I abbreviated Star Wars as SW when inputting my answers, when inputting player guesses,
you need to input SW
 */

//Definitions
/*
 *Placement refers to the users placement at the end of the jeopardy before the final jeopardy
 *Position refers to the players position in the turn order of the final jeopardy
 *Ranked vs Unranked:
 ** Ranked: This means that your object are ranked and will be sorted in order once you are done inputting them
 *** This also means that the final jeopardy will be easier because players can see correct answers and their rankings

 ** Unranked: This means that your object are just a list of the correct answers, and they do not have a rank
 *** This makes for a harder jeopardy question because players do not get the added information of the rank of the object
 */

public class Main {
    private static int counter = 0; //used to fix scanner issues
    private static int fileCounter = 0; //used to fix scanner issues
    private static int nextAvailableHint = 0;
    private static int roundCounter = 1;
    private static int hintsPerTurn = 1;

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        //holds all possible categoryTypes
        final String[] validCategories = {"ranked characters", "rc", "unranked characters", "uc", "ranked anime", "ra", "unranked anime", "ua", "ranked video games", "rvg", "unranked video games", "uvg" };

        System.out.print("Please enter the number of participants of the final jeopardy: ");

        int participants = 0; //number of participants in the game

        boolean continueLoop = true;
        while (continueLoop) {
            participants = validIntInput(scan);
            if (participants > 1) {
                continueLoop = false;
            }//end if (participants > 1)
            else {
                System.out.println("Number is not in valid Range participants > 1. Please Try again");
                System.out.print("Enter the number of participants: ");
            }//end else
        }//end while loop

        Player[] players = new Player[participants]; //the array used to hold the participants

        createPlayers(participants, players, scan); // call the function that makes the players

        sortPlayerArray(players); //Sorts the player array using position variable

        printPlayers(players);

        //ensure that only a valid category or its abbreviation is stored in category type
        String categoryType = validCategory(validCategories, scan);

        boolean fileExists = false;


        if (categoryType.contains("ranked") || (categoryType.equalsIgnoreCase("rc") || categoryType.equalsIgnoreCase("ra") || categoryType.equalsIgnoreCase("rvg"))) {
            System.out.print("\n\nDo you have a txt File (comma separated) that has all the answers listed in order based on rank (lower number first)\nAND it follows the following format: Rank (number only),Name,Piece of media or release year\n");
            String hasRankedFile = validAnswer(scan);

            List<String> allAnswers;
            if (hasRankedFile.equalsIgnoreCase("yes") || hasRankedFile.equalsIgnoreCase("y")) {
                System.out.print("How many unique answers are in your list: ");
                int numberOfObjects = validIntInput(scan);
                String pathUpToFile = "src/resources/";
                System.out.print("Enter the name of the txt file with answers: ");
                scan.nextLine();
                String csvFile = scan.nextLine();
                csvFile = pathUpToFile.concat(csvFile);
                allAnswers = new ArrayList<>();

                try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
                    fileExists = true;
                    String line;

                    while ((line = br.readLine()) != null) {
                        // Split the line into values using a comma as the delimiter
                        String modifiedLine = line.replaceAll("[^a-zA-Z0-9,.:?!();'\"-]", " ");
                        String[] values = modifiedLine.split(",");

                        // Add all values to the list
                        allAnswers.addAll(Arrays.asList(values));
                    }//end while ((line = br.readLine()) != null)
                    createCategoryArrayUsingFile(players, allAnswers, numberOfObjects, categoryType, scan);
                } catch (IOException e) {
                    System.out.println("Could not find file. Please enter values manually.");

                } catch(Exception e) {
                    System.out.println("Error, Please check the file to make sure elements are in correct order and formatted properly\nAlso check if the number of unique answers matches the number you inputted");
                }//end try catch

            }//end if (hasRankedFile.equalsIgnoreCase("yes") || hasRankedFile.equalsIgnoreCase("y"))
        }//end if (ranked)

        else {
            System.out.print("Do you have a txt File (comma separated) with all the answers in the following format: Name,Piece of media/Release year\n");
            String hasFile = validAnswer(scan);

            List<String> allAnswers;
            if (hasFile.equalsIgnoreCase("yes") || hasFile.equalsIgnoreCase("y")) {
                System.out.print("How many unique answers are in your list: ");
                int numberOfObjects = validIntInput(scan);
                String pathUpToFile = "src/resources/";
                System.out.print("Enter the name of the txt file with answers: ");
                scan.nextLine();
                String csvFile = scan.nextLine();
                csvFile = pathUpToFile.concat(csvFile);
                allAnswers = new ArrayList<>();

                try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
                    fileExists = true;
                    String line;

                    while ((line = br.readLine()) != null) {
                        // Split the line into values using a comma as the delimiter
                        String modifiedLine = line.replaceAll("[^a-zA-Z0-9,.:?!();'\"-]", " ");
                        String[] values = modifiedLine.split(",");

                        // Add all values to the list
                        allAnswers.addAll(Arrays.asList(values));
                    }//end while ((line = br.readLine()) != null)
                    createCategoryArrayUsingFile(players, allAnswers, numberOfObjects, categoryType, scan);
                } catch (IOException e) {
                    System.out.println("Could not find file. Please enter values manually.");
                } catch(Exception e) {
                    System.out.println("Error, Please check the file to make sure elements are in correct order and formatted properly\nAlso check if the number of unique answers matches the number you inputted");
                }//end try catch
            }//end if (hasRankedFile.equalsIgnoreCase("yes") || hasRankedFile.equalsIgnoreCase("y"))
        }//end else

        if (!fileExists) {
            createCategoryArray(players, categoryType, scan); //creates the array based on the category
        }//end if (!fileExists)

    }//end Main method

    /*********************************************************************/
    //Create Methods

    public static void createPlayers(int participants, Player[] players, Scanner scan) {
        ArrayList<String> namesAlreadyUsed = new ArrayList<>(); //stores all names already taken
        ArrayList<Integer> placementsAlreadyUsed = new ArrayList<>(); //stores all placements already taken
        ArrayList<Integer> positionsAlreadyUsed = new ArrayList<>(); //stores all positions already taken

        int maxHintDecider;
        int maxHints;

        maxHintDecider = Integer.compare(participants, 3);

        //loops through creating players
        for (int i = 0; i < participants; i++) {

            String name = validPlayerName(namesAlreadyUsed, i, scan); //The name of the player

            addPlayerName(namesAlreadyUsed, name);

            //uses the validPlacement Method to ensure only a valid placement that has not been assigned is stored
            //placement refers to the place of the user at the end of the jeopardy before the final jeopardy
            int placement = validPlacement(placementsAlreadyUsed, players.length, scan);

            //Once a valid placement is found and stored in the variable directly above
            //Call addPlacement to add the placement to the placementsAlreadyUsed Arraylist
            addPlacement(placementsAlreadyUsed, placement);

            //uses the validPosition Method to ensure only a valid position that has not been assigned is stored
            //position refers to the turn order of the final jeopardy
            int position = validPosition(positionsAlreadyUsed, players.length, scan);

            //Once a valid placement is found and stored in the variable directly above
            //Call addPosition to add the position to the positionsAlreadyUsed Arraylist
            addPosition(positionsAlreadyUsed, position);

            //Calls validIntInput to ensure the user enters a valid int value for lives
            System.out.print("Enter the amount of lives player " + (i + 1) + " starts with: ");
            int lives = validIntInput(scan);

            //Creates the player with all valid inputs
            players[i] = new Player(name, placement, position, lives);

            switch (maxHintDecider) {
                case -1:
                    break;

                case 0:
                    if (players[i].getPlacement() == 1) {
                        maxHints = 1;
                        players[i].setHints(maxHints);
                    }//end if (players[i].getPlacement() == 1)
                    break;

                case 1:
                    switch(players[i].getPlacement()) {
                        case 1:
                            players[i].setHints(3);
                            break;

                        case 2:
                            players[i].setHints(2);
                            break;

                        case 3:
                            players[i].setHints(1);
                            break;

                        default:
                            break;
                    }//end switch(players[i].getPlacement())
                    break;
            }//end switch (maxHintDecider)

        }//end for (int i = 0; i < participants; i++)

    }//end createPlayers

    public static void createCategoryArrayUsingFile(Player[] players, List<String> objects, int numberOfAnswers, String categoryType, Scanner scan) {
        //checks for the ranked character category
        int rank;
        String name;
        String series;
        String releaseYear;

        boolean usedFile = true;

        if (categoryType.equalsIgnoreCase("ranked characters") || categoryType.equalsIgnoreCase("rc")) {
            Character[] listOfCharacters = new Character[numberOfAnswers];
            for (int i = 0, j = 0; i < numberOfAnswers && j < objects.size(); i++, j+=3) {
                rank = Integer.parseInt(objects.get(j).trim());
                name = objects.get(j+1).trim();
                series = objects.get(j+2).trim();
                listOfCharacters[i] = new Character(name, series, rank);
            }//end for (int i = 0, j = 0; i < numberOfAnswers && j < objects.size(); i++, j+=3)

            SortCharacterArray(listOfCharacters);

            characterFinalJeopardy(listOfCharacters, players, categoryType, scan, usedFile);

        }//end if (ranked character category)

        //checks for the unranked character category
        else if (categoryType.equalsIgnoreCase("unranked characters") || categoryType.equalsIgnoreCase("uc")){
            Character[] listOfCharacters = new Character[numberOfAnswers];
            for (int i = 0, j = 0; i < numberOfAnswers && j < objects.size(); i++, j+=2) {
                name = objects.get(j).trim();
                series = objects.get(j+1).trim();
                listOfCharacters[i] = new Character(name, series);
            }//end for (int i = 0, j = 0; i < numberOfAnswers && j < objects.size(); i++, j+=2)

            characterFinalJeopardy(listOfCharacters, players, categoryType, scan, usedFile);

        }//end else if (unranked character category

        //checks for ranked anime category
        else if (categoryType.equalsIgnoreCase("ranked anime") || categoryType.equalsIgnoreCase("ra")){
            Anime[] listOfAnime = new Anime[numberOfAnswers];
            for (int i = 0, j = 0; i < numberOfAnswers && j < objects.size(); i++, j+=3) {
                rank = Integer.parseInt(objects.get(j).trim());
                name = objects.get(j+1).trim();
                releaseYear = objects.get(j+2).trim();
                listOfAnime[i] = new Anime(name, releaseYear, rank);
            }//end for (int i = 0, j = 0; i < numberOfAnswers && j < objects.size(); i++, j+=3)

            SortAnimeArray(listOfAnime);

            animeFinalJeopardy(listOfAnime, players, categoryType, scan, usedFile);

        }//end else if (ranked anime category)

        //checks for unranked anime category
        else if (categoryType.equalsIgnoreCase("unranked anime") || categoryType.equalsIgnoreCase("ua")){
            Anime[] listOfAnime = new Anime[numberOfAnswers];
            for (int i = 0, j = 0; i < numberOfAnswers && j < objects.size(); i++, j+=2) {
                name = objects.get(j).trim();
                releaseYear = objects.get(j+1).trim();
                listOfAnime[i] = new Anime(name, releaseYear);
            }//end for (int i = 0, j = 0; i < numberOfAnswers && j < objects.size(); i++, j+=2)

            animeFinalJeopardy(listOfAnime, players, categoryType, scan, usedFile);

        }//end else if (unranked anime category)

        //checks for ranked video games category
        else if (categoryType.equalsIgnoreCase("ranked video games") || categoryType.equalsIgnoreCase("rvg")){
            VideoGame[] listOfVideoGames = new VideoGame[numberOfAnswers];
            for (int i = 0, j = 0; i < numberOfAnswers && j < objects.size(); i++, j+=3) {
                rank = Integer.parseInt(objects.get(j).trim());
                name = objects.get(j+1).trim();
                releaseYear = objects.get(j+2).trim();
                listOfVideoGames[i] = new VideoGame(name, releaseYear, rank);
            }//end for (int i = 0, j = 0; i < numberOfAnswers && j < objects.size(); i++, j+=3)

            SortVideoGameArray(listOfVideoGames);

            videoGameFinalJeopardy(listOfVideoGames, players, categoryType, scan, usedFile);

        }//end else if (ranked video game category)

        //checks for unranked video games category
        else if (categoryType.equalsIgnoreCase("unranked video games") || categoryType.equalsIgnoreCase("uvg")){
            VideoGame[] listOfVideoGames = new VideoGame[numberOfAnswers];
            for (int i = 0, j = 0; i < numberOfAnswers && j < objects.size(); i++, j+=2) {
                name = objects.get(j).trim();
                releaseYear = objects.get(j+1).trim();
                listOfVideoGames[i] = new VideoGame(name, releaseYear);
            }//end for (int i = 0, j = 0; i < numberOfAnswers && j < objects.size(); i++, j+=2)

            videoGameFinalJeopardy(listOfVideoGames, players, categoryType, scan, usedFile);

        }//end else if (unranked video game category)

        else {
            System.out.println("Something went wrong ending program");
            System.exit(0);
        }//end else
    }//end createCategoryArrayUsingFile

    public static void createCategoryArray(Player[] players, String categoryType, Scanner scan) {
        int numberOfAnswers; //stores the amount answers you want for the question

        boolean usedFile = false;

        //checks for the ranked character category
        if (categoryType.equalsIgnoreCase("ranked characters") || categoryType.equalsIgnoreCase("rc")) {
            System.out.print("Please enter the number of characters in your list: ");

            numberOfAnswers = validIntInput(scan); //ensures a valid int input is stored in number of answers

            Character[] listOfCharacters = createRankedCharacters(numberOfAnswers, scan);

            SortCharacterArray(listOfCharacters);

            characterFinalJeopardy(listOfCharacters, players, categoryType, scan, usedFile);

        }//end if (ranked character category)

        //checks for the unranked character category
        else if (categoryType.equalsIgnoreCase("unranked characters") || categoryType.equalsIgnoreCase("uc")){
            System.out.print("Please enter the number of characters in your list: ");

            numberOfAnswers = validIntInput(scan); //ensures a valid int input is stored in number of answers

            Character[] listOfCharacters = createUnrankedCharacters(numberOfAnswers, scan);

            characterFinalJeopardy(listOfCharacters, players, categoryType, scan, usedFile);

        }//end else if (unranked character category

        //checks for ranked anime category
        else if (categoryType.equalsIgnoreCase("ranked anime") || categoryType.equalsIgnoreCase("ra")){
            System.out.print("Please enter the number of anime in your list: ");

            numberOfAnswers = validIntInput(scan); //ensures a valid int input is stored in number of answers

            Anime[] listOfAnime = createRankedAnime(numberOfAnswers, scan);

            SortAnimeArray(listOfAnime);

            animeFinalJeopardy(listOfAnime, players, categoryType, scan, usedFile);

        }//end else if (ranked anime category)

        //checks for unranked anime category
        else if (categoryType.equalsIgnoreCase("unranked anime") || categoryType.equalsIgnoreCase("ua")){
            System.out.print("Please enter the number of anime in your list: ");

            numberOfAnswers = validIntInput(scan); //ensures a valid int input is stored in number of answers

            Anime[] listOfAnime = createUnrankedAnime(numberOfAnswers, scan);

            animeFinalJeopardy(listOfAnime, players, categoryType, scan, usedFile);

        }//end else if (unranked anime category)

        //checks for ranked video games category
        else if (categoryType.equalsIgnoreCase("ranked video games") || categoryType.equalsIgnoreCase("rvg")){
            System.out.print("Please enter the number of video games in your list: ");

            numberOfAnswers = validIntInput(scan); //ensures a valid int input is stored in number of answers

            VideoGame[] listOfVideoGames = createRankedVideoGame(numberOfAnswers, scan);

            SortVideoGameArray(listOfVideoGames);

            videoGameFinalJeopardy(listOfVideoGames, players, categoryType, scan, usedFile);

        }//end else if (ranked video game category)

        //checks for unranked video games category
        else if (categoryType.equalsIgnoreCase("unranked video games") || categoryType.equalsIgnoreCase("uvg")){
            System.out.print("Please enter the number of video games in your list: ");

            numberOfAnswers = validIntInput(scan); //ensures a valid int input is stored in number of answers

            VideoGame[] listOfVideoGames = createUnrankedVideoGame(numberOfAnswers, scan);

            videoGameFinalJeopardy(listOfVideoGames, players, categoryType, scan, usedFile);

        }//end else if (unranked video game category)

        else {
            System.out.println("Something went wrong ending program");
            System.exit(0);
        }//end else

    }//end createCategoryArray

    public static Character[] createRankedCharacters(int numberOfCharacters, Scanner scan) {
        Character[] listOfCharacters = new Character[numberOfCharacters]; //create array of characters
        ArrayList<Integer> ranksAlreadyUsed = new ArrayList<>(); //create array list of rankings that have already been used

        //loop to create amount of desired characters
        for (int i = 0; i < numberOfCharacters; i++) {
            System.out.print("Enter Character " + (i+1) + "'s name: ");
            scan.nextLine();
            String name = scan.nextLine();

            System.out.print("Enter the media that they are from: ");
            String series = scan.nextLine();

            int rank = validRank(ranksAlreadyUsed, numberOfCharacters, scan);

            addRank(ranksAlreadyUsed, rank);

            listOfCharacters[i] = new Character(name, series, rank);
        }//end for (int i = 0; i < numberOfCharacters; i++)

        return listOfCharacters;
    }//end createRankedCharacters

    public static Character[] createUnrankedCharacters(int numberOfCharacters, Scanner scan) {
        Character[] listOfCharacters = new Character[numberOfCharacters]; //create array of characters

        //loop to create amount of desired characters
        scan.nextLine();
        for (int i = 0; i < numberOfCharacters; i++) {
            System.out.print("Enter Character " + (i+1) + "'s name: ");
            String name = scan.nextLine();

            System.out.print("Enter the media they are from: ");
            String series = scan.nextLine();
            listOfCharacters[i] = new Character(name, series);
        }//end for (int i = 0; i < numberOfCharacters; i++)
        return listOfCharacters;
    }//end createUnrankedCharacters

    public static Anime[] createRankedAnime(int numberOfAnime, Scanner scan) {
        Anime[] listOfAnime = new Anime[numberOfAnime]; //create array of characters
        ArrayList<Integer> ranksAlreadyUsed = new ArrayList<>(); //create array list of rankings that have already been used

        //loop to create amount of desired characters
        for (int i = 0; i < numberOfAnime; i++) {
            System.out.print("Enter Anime " + (i+1) + ": ");
            scan.nextLine();
            String name = scan.nextLine();

            System.out.print("Enter the year it released: ");
            String releaseYear = scan.nextLine();

            int rank = validRank(ranksAlreadyUsed, numberOfAnime, scan);

            addRank(ranksAlreadyUsed, rank);

            listOfAnime[i] = new Anime(name, releaseYear, rank);
        }//end for (int i = 0; i < numberOfCharacters; i++)

        return listOfAnime;
    }//end createRankedAnime

    public static Anime[] createUnrankedAnime(int numberOfAnime, Scanner scan) {
        Anime[] listOfAnime = new Anime[numberOfAnime]; //create array of characters

        //loop to create amount of desired characters
        scan.nextLine();
        for (int i = 0; i < numberOfAnime; i++) {
            System.out.print("Enter Anime " + (i+1) + ": ");
            String name = scan.nextLine();

            System.out.print("Enter the year it released: ");
            String releaseYear = scan.nextLine();

            listOfAnime[i] = new Anime(name, releaseYear);
        }//end for (int i = 0; i < numberOfCharacters; i++)
        return listOfAnime;
    }//end createUnrankedAnime

    public static VideoGame[] createRankedVideoGame(int numberOfVideoGames, Scanner scan) {
        VideoGame[] listOfVideoGames = new VideoGame[numberOfVideoGames]; //create array of characters
        ArrayList<Integer> ranksAlreadyUsed = new ArrayList<>(); //create array list of rankings that have already been used

        //loop to create amount of desired characters
        for (int i = 0; i < numberOfVideoGames; i++) {
            System.out.print("Enter Video Game " + (i+1) + ": ");
            scan.nextLine();
            String name = scan.nextLine();

            System.out.print("Enter the year it released: ");
            String releaseYear = scan.nextLine();

            int rank = validRank(ranksAlreadyUsed, numberOfVideoGames, scan);

            addRank(ranksAlreadyUsed, rank);

            listOfVideoGames[i] = new VideoGame(name, releaseYear, rank);
        }//end for (int i = 0; i < numberOfCharacters; i++)

        return listOfVideoGames;
    }//end createRankedVideoGame

    public static VideoGame[] createUnrankedVideoGame(int numberOfVideoGames, Scanner scan) {
        VideoGame[] listOfVideoGames = new VideoGame[numberOfVideoGames]; //create array of characters

        //loop to create amount of desired characters
        scan.nextLine();
        for (int i = 0; i < numberOfVideoGames; i++) {
            System.out.print("Enter Video Game " + (i+1) + ": ");
            String name = scan.nextLine();
            System.out.print("Enter the year it released: ");
            String releaseYear = scan.nextLine();

            listOfVideoGames[i] = new VideoGame(name, releaseYear);
        }//end for (int i = 0; i < numberOfCharacters; i++)
        return listOfVideoGames;
    }//end createUnrankedVideoGame

    /*****************************************************************************************************************/
    //Final Jeopardy Methods

    public static void characterFinalJeopardy(Character[] characters, Player[] players, String category, Scanner scan, boolean usedFile) {
        int numberOfPlayersWithLives = players.length; //tracks number of players with lives left
        ArrayList<Character> correctGuesses = new ArrayList<>();
        ArrayList<Character> incorrectGuesses = new ArrayList<>();
        ArrayList<Character> characterWithHints = new ArrayList<>();
        int firstGuess = 0;

        while (numberOfPlayersWithLives != 1 && correctGuesses.size() != characters.length) {
            for (Player currentPlayer : players) {
                if (numberOfPlayersWithLives != 1 && correctGuesses.size() != characters.length) {
                    if (currentPlayer.getLives() != 0) {
                        System.out.println("\nPlayer Turn: " + currentPlayer.getName() + " | Remaining Live(s): " + currentPlayer.getLives() + "\n");
                        if (firstGuess != 0) {
                            characterMenuOptions(currentPlayer, characters, correctGuesses, incorrectGuesses, characterWithHints, category, scan);
                        }//end if (firstGuess != 0)
                        characterPlayerTurn(currentPlayer, characters, correctGuesses, incorrectGuesses, characterWithHints, category, scan, usedFile);
                        firstGuess = 1;
                    }//end if (currentPlayer.getLives() != 0)
                    numberOfPlayersWithLives = updateRemainingPlayers(players);
                }//end if (numberOfPlayersWithLives != 1 && correctGuesses.size() != characters.length)
                else {
                    break;
                }//end else
            }//end for (Player currentPlayer : players) {
            roundCounter++;
        }//end while loop
        String winner = assignWinner(players);

        System.out.println(winner);
    }//end characterFinalJeopardy

    public static void animeFinalJeopardy(Anime[] anime, Player[] players, String category, Scanner scan, boolean usedFile) {
        int numberOfPlayersWithLives = players.length; //tracks number of players with lives left
        ArrayList<Anime> correctGuesses = new ArrayList<>();
        ArrayList<Anime> incorrectGuesses = new ArrayList<>();
        ArrayList<Anime> animeWithHints = new ArrayList<>();
        int firstGuess = 0;

        while (numberOfPlayersWithLives != 1 && correctGuesses.size() != anime.length) {
            for (Player currentPlayer : players) {
                if (numberOfPlayersWithLives != 1 && correctGuesses.size() != anime.length) {
                    if (currentPlayer.getLives() != 0) {
                        System.out.println("\nPlayer Turn: " + currentPlayer.getName() + "\n");
                        if (firstGuess != 0) {
                            animeMenuOptions(currentPlayer, anime, correctGuesses, incorrectGuesses, animeWithHints, category, scan);
                        }//end if (firstGuess != 0)
                        animePlayerTurn(currentPlayer, anime, correctGuesses, incorrectGuesses, animeWithHints, category, scan, usedFile);
                        firstGuess = 1;
                    }//end if (currentPlayer.getLives() != 0)
                    numberOfPlayersWithLives = updateRemainingPlayers(players);
                }//end if (numberOfPlayersWithLives != 1 && correctGuesses.size() != anime.length)
                else {
                    break;
                }//end else
            }//end for (Player currentPlayer : players) {
            roundCounter++;
        }//end while loop
        String winner = assignWinner(players);

        System.out.println(winner);
    }//end animeFinalJeopardy

    public static void videoGameFinalJeopardy(VideoGame[] videoGames, Player[] players, String category, Scanner scan, boolean usedFile) {
        int numberOfPlayersWithLives = players.length; //tracks number of players with lives left
        ArrayList<VideoGame> correctGuesses = new ArrayList<>();
        ArrayList<VideoGame> incorrectGuesses = new ArrayList<>();
        ArrayList<VideoGame> videoGamesWithHints = new ArrayList<>();
        int firstGuess = 0;

        while (numberOfPlayersWithLives != 1 && correctGuesses.size() != videoGames.length) {
            for (Player currentPlayer : players) {
                if (numberOfPlayersWithLives != 1 && correctGuesses.size() != videoGames.length) {
                    if (currentPlayer.getLives() != 0) {
                        System.out.println("\nPlayer Turn: " + currentPlayer.getName() + "\n");
                        if (firstGuess != 0) {
                            videoGameMenuOptions(currentPlayer, videoGames, correctGuesses, incorrectGuesses, videoGamesWithHints, category, scan);
                        }//end if (firstGuess != 0)
                        videoGamePlayerTurn(currentPlayer, videoGames, correctGuesses, incorrectGuesses, videoGamesWithHints, category, scan, usedFile);
                        firstGuess = 1;
                    }//end if (currentPlayer.getLives() != 0)
                    numberOfPlayersWithLives = updateRemainingPlayers(players);
                }//end if (numberOfPlayersWithLives != 1 && correctGuesses.size() != videoGames.length)
                else {
                    break;
                }//end else
            }//end for (Player currentPlayer : players) {
            roundCounter++;
        }//end while loop
        String winner = assignWinner(players);

        System.out.println(winner);
    }//end videoGameFinalJeopardy

    /*****************************************************************************************************************/
    //Player Turn Methods

    public static void characterPlayerTurn(Player player, Character[] characters, ArrayList<Character> correctGuesses, ArrayList<Character> incorrectGuesses, ArrayList<Character> charactersWithHints, String category, Scanner scan, boolean usedFile) {
        boolean repeat = true;
        String name = "";
        String series = "";
        if (!usedFile) {
            if (category.equalsIgnoreCase("ranked characters") || category.equalsIgnoreCase("rc")) {
                while(repeat) {
                    if (counter == 0) {
                        System.out.print(player.getName() + " Name a character: ");
                        scan.nextLine();
                        name = scan.nextLine();
                        System.out.print("Enter the media the character is from: ");
                        series = scan.nextLine();
                    }
                    else {
                        System.out.print(player.getName() + " Name a character: ");
                        name = scan.nextLine();
                        System.out.print("Enter the media the character is from: ");
                        series = scan.nextLine();
                    }
                    if (isCharacterGuessARepeat(correctGuesses, incorrectGuesses, name, series)) {
                        System.out.println("\nGuess has already been said please try again.\n");
                        counter++;
                    }//end ifCharacterGuessIsARepeat
                    else {
                        repeat = false;
                        counter = 0;
                    }//end else
                }//end while loop
            }//end if (ranked characters)

            else if (category.equalsIgnoreCase("unranked characters") || category.equalsIgnoreCase("uc")) {
                while(repeat) {
                    if (counter % 2 != 0 && counter <= 2) {
                        scan.nextLine();
                    }
                    System.out.print(player.getName() + " Name a character: ");
                    name = scan.nextLine();
                    System.out.print("Enter the media the character is from: ");
                    series = scan.nextLine();
                    if (isCharacterGuessARepeat(correctGuesses, incorrectGuesses, name, series)) {
                        System.out.println("\nGuess has already been said please try again.\n");
                    }//end ifCharacterGuessIsARepeat
                    else {
                        repeat = false;
                        counter = 0;
                    }//end else
                    counter++;
                }//end while loop
            }//end else if (unranked characters)

        }//end if (!usedFile)

        else {
            while(repeat) {
                if (fileCounter % 2 == 0 || fileCounter > 2) {
                    System.out.print(player.getName() + " Name a character: ");
                    name = scan.nextLine();
                    System.out.print("Enter the media the character is from: ");
                    series = scan.nextLine();
                }
                else {
                    System.out.print(player.getName() + " Name a character: ");
                    scan.nextLine();
                    name = scan.nextLine();
                    System.out.print("Enter the media the character is from: ");
                    series = scan.nextLine();
                }
                if (isCharacterGuessARepeat(correctGuesses, incorrectGuesses, name, series)) {
                    System.out.println("\nGuess has already been said please try again.\n");
                }//end ifCharacterGuessIsARepeat
                else {
                    repeat = false;
                    fileCounter = 0;
                }//end else
                fileCounter++;
            }//end while loop

        }//end else

        if (isCharacterInArray(characters, name, series)) {
            // Add the character to the correctGuess array
            addCorrectCharacterGuess(correctGuesses, getCorrectCharacter(characters, name, series));

            Iterator<Character> iterator = charactersWithHints.iterator();
            while (iterator.hasNext()) {
                Character currentCharacter = iterator.next();
                if (isCharacterInArrayList(currentCharacter, charactersWithHints)) {
                    iterator.remove();
                    break;
                }//end if (isCharacterInArrayList(currentCharacter, charactersWithHints))
            }//end while (iterator.hasNext())

            System.out.println("\nCorrect!");
            if (category.equalsIgnoreCase("ranked characters") || category.equalsIgnoreCase("rc")) {
                sortCorrectCharacterGuesses(correctGuesses);
            }//end if (ranked characters)
        }//end if (isCharacterInArray(characters, characterGuess))

        else {
            addIncorrectCharacterGuesses(incorrectGuesses, name, series);
            updateLives(player);
            System.out.println("\nIncorrect. " + player.getName() + " has " + player.getLives() + " live(s).");
        }//end else

    }//end characterPlayerTurn

    public static void animePlayerTurn(Player player, Anime[] anime, ArrayList<Anime> correctGuesses, ArrayList<Anime> incorrectGuesses, ArrayList<Anime> animeWithHints, String category, Scanner scan, boolean usedFile) {
        boolean repeat = true;
        String name = "";
        String releaseYear = "";
        if (!usedFile) {
            if (category.equalsIgnoreCase("ranked anime") || category.equalsIgnoreCase("ra")) {
                while (repeat) {
                    if (counter == 0) {
                        System.out.print(player.getName() + " Name an anime: ");
                        scan.nextLine();
                        name = scan.nextLine();
                        System.out.print("Enter the year of its release: ");
                        releaseYear = scan.nextLine();
                    }
                    else {
                        System.out.print(player.getName() + " Name an anime: ");
                        name = scan.nextLine();
                        System.out.print("Enter the year of its release: ");
                        releaseYear = scan.nextLine();
                    }

                    if (isAnimeGuessARepeat(correctGuesses, incorrectGuesses, name, releaseYear)) {
                        System.out.println("\nGuess has already been said please try again.\n");
                        counter++;
                    }//end if
                    else {
                        repeat = false;
                        counter = 0;
                    }//end else
                }//end while loop
            }//end if (ranked anime)

            else if (category.equalsIgnoreCase("unranked anime") || category.equalsIgnoreCase("ua")) {
                while (repeat) {
                    if (counter % 2 != 0 && counter <= 2) {
                        scan.nextLine();
                    }//end if (counter % 2 != 0 && counter <= 2)
                    System.out.print(player.getName() + " Name an anime: ");
                    name = scan.nextLine();
                    System.out.print("Enter the year of its release: ");
                    releaseYear = scan.nextLine();
                    if (isAnimeGuessARepeat(correctGuesses, incorrectGuesses, name, releaseYear)) {
                        System.out.println("\nGuess has already been said please try again.\n");
                    }//end if
                    else {
                        repeat = false;
                        counter = 0;
                    }//end else
                    counter++;
                }//end while loop
            }//end else if (unranked anime)

        }//end if (!usedFile)

        else {
            while (repeat) {
                if (fileCounter % 2 == 0 || fileCounter > 2) {
                    System.out.print(player.getName() + " Name an anime: ");
                    name = scan.nextLine();
                    System.out.print("Enter the year of its release: ");
                    releaseYear = scan.nextLine();
                }
                else {
                    System.out.print(player.getName() + " Name an anime: ");
                    scan.nextLine();
                    name = scan.nextLine();
                    System.out.print("Enter the year of its release: ");
                    releaseYear = scan.nextLine();
                }

                if (isAnimeGuessARepeat(correctGuesses, incorrectGuesses, name, releaseYear)) {
                    System.out.println("\nGuess has already been said please try again.\n");
                }//end if
                else {
                    repeat = false;
                    fileCounter = 0;
                }//end
                fileCounter++;
            }//end while loop

        }//end else

        if (isAnimeInArray(anime, name, releaseYear)) {
            //Add the anime to the correctGuess array
            addCorrectAnimeGuess(correctGuesses, getCorrectAnime(anime, name, releaseYear));

            Iterator<Anime> iterator = animeWithHints.iterator();
            while (iterator.hasNext()) {
                Anime currentAnime = iterator.next();
                if (isAnimeInArrayList(currentAnime, animeWithHints)) {
                    iterator.remove();
                    break;
                }//end if (isAnimeInArrayList(currentAnime, animeWithHints))
            }//end while (iterator.hasNext())

            System.out.println("\nCorrect!");
            if (category.equalsIgnoreCase("ranked anime") || category.equalsIgnoreCase("ra")) {
                sortCorrectAnimeGuesses(correctGuesses);
            }//end if (ranked anime)
        }//end if (isAnimeInArray(anime, name, releaseYear))

        else {
            addIncorrectAnimeGuesses(incorrectGuesses, name, releaseYear);
            updateLives(player);
            System.out.println("\nIncorrect. " + player.getName() + " has " + player.getLives() + " live(s).");
        }//end else


    }//end animePlayerTurn

    public static void videoGamePlayerTurn(Player player, VideoGame[] videoGames, ArrayList<VideoGame> correctGuesses, ArrayList<VideoGame> incorrectGuesses, ArrayList<VideoGame> videoGameWithHints, String category, Scanner scan, boolean usedFile) {
        boolean repeat = true;
        String name = "";
        String releaseYear = "";

        if (!usedFile) {
            if (category.equalsIgnoreCase("ranked video games") || category.equalsIgnoreCase("rvg")) {
                while (repeat) {
                    if (counter == 0) {
                        System.out.print(player.getName() + " Name a video game: ");
                        scan.nextLine();
                        name = scan.nextLine();
                        System.out.print("Enter the year of its release: ");
                        releaseYear = scan.nextLine();
                    }
                    else {
                        System.out.print(player.getName() + " Name a video game: ");
                        name = scan.nextLine();
                        System.out.print("Enter the year of its release: ");
                        releaseYear = scan.nextLine();
                    }
                    if (isVideoGameGuessARepeat(correctGuesses, incorrectGuesses, name, releaseYear)) {
                        System.out.println("\nGuess has already been said please try again.\n");
                        counter++;
                    }//end if
                    else {
                        repeat = false;
                        counter = 0;
                    }//end else
                }//end while loop
            }//end if

            else if (category.equalsIgnoreCase("unranked video games") || category.equalsIgnoreCase("uvg")) {
                while (repeat) {
                    if (counter % 2 != 0 && counter <= 2) {
                        scan.nextLine();
                    }//end if (counter % 2 != 0 && counter <= 2)
                    System.out.print(player.getName() + " Name a video game: ");
                    name = scan.nextLine();
                    System.out.print("Enter the year of its release: ");
                    releaseYear = scan.nextLine();
                    if (isVideoGameGuessARepeat(correctGuesses, incorrectGuesses, name, releaseYear)) {
                        System.out.println("\nGuess has already been said please try again.\n");
                    }//end if
                    else {
                        repeat = false;
                        counter = 0;
                    }//end else
                    counter++;
                }//end while loop
            }//end else if (unranked video games)

        }//end (!usedFile)

        else {
            while (repeat) {
                if (fileCounter % 2 == 0 || fileCounter > 2) {
                    System.out.print(player.getName() + " Name a video game: ");
                    name = scan.nextLine();
                    System.out.print("Enter the year of its release: ");
                    releaseYear = scan.nextLine();
                }
                else {
                    System.out.print(player.getName() + " Name a video game: ");
                    scan.nextLine();
                    name = scan.nextLine();
                    System.out.print("Enter the year of its release: ");
                    releaseYear = scan.nextLine();
                }
                if (isVideoGameGuessARepeat(correctGuesses, incorrectGuesses, name, releaseYear)) {
                    System.out.println("\nGuess has already been said please try again.\n");
                }//end if
                else {
                    repeat = false;
                    fileCounter = 0;
                }//end else
                fileCounter++;
            }//end while loop
        }//end else


        if (isVideoGameInArray(videoGames, name, releaseYear)) {
            //Add the video game to the correctGuess array
            addCorrectVideoGameGuess(correctGuesses, getCorrectVideoGame(videoGames, name, releaseYear));

            Iterator<VideoGame> iterator = videoGameWithHints.iterator();
            while (iterator.hasNext()) {
                VideoGame currentVideoGame = iterator.next();
                if (isVideoGameInArrayList(currentVideoGame, videoGameWithHints)) {
                    iterator.remove();
                    break;
                }//end if (isVideoGameInArrayList(currentVideoGame, videoGameWithHints))
            }//end while (iterator.hasNext())

            System.out.println("\nCorrect!");
            if (category.equalsIgnoreCase("ranked video games") || category.equalsIgnoreCase("rvg")) {
                sortCorrectVideoGameGuesses(correctGuesses);
            }//end if (ranked video game)
        }//end if (isVideoGameInArray(videoGames, name, releaseYear))

        else {
            addIncorrectVideoGameGuesses(incorrectGuesses, name, releaseYear);
            updateLives(player);
            System.out.println("\nIncorrect. " + player.getName() + " has " + player.getLives() + " live(s).");
        }//end else

    }//end videoGamePlayerTurn

    /***************************************************************************************************************/
    //Menu Option Methods

    public static void characterMenuOptions(Player player, Character[] characters, ArrayList<Character> correctGuesses, ArrayList<Character> incorrectGuesses, ArrayList<Character> characterWithHints, String category, Scanner scan) {
        int options = 0;
        int choice;

        if (category.equalsIgnoreCase("ranked characters") || category.equalsIgnoreCase("rc")) {
            while (options != -1) {
                if (roundCounter == 1 || hintsPerTurn != 1 || player.getHints() == 0 || nextAvailableHint == characters.length) {
                    System.out.print("Enter 1 to see the correct guesses so far\nEnter 2 to see the incorrect guesses so far\nEnter 3 to see all used hints\nEnter 0 to continue: ");
                }
                else {
                    System.out.print("Enter 1 to see the correct guesses so far\nEnter 2 to see the incorrect guesses so far\nEnter 3 to see all used hints\nEnter 4 to use a hint. Hints Remaining: " + player.getHints() + "\nEnter 0 to continue: ");
                }

                choice = validIntInput(scan);

                switch(choice) {
                    case 0:
                        options = -1;
                        System.out.println();
                        break;
                    case 1:
                        if (correctGuesses.isEmpty()) {
                            System.out.println("\nThere are no correct Guesses\n");
                        }//end if (correctGuesses.isEmpty())
                        else {
                            System.out.println();
                            for (Character character : correctGuesses) {
                                System.out.println(character.getRank() + ". " + character.getName() + " | " + character.getSeries());
                            }//end for (Character character : correctGuesses)
                            System.out.println();
                        }//end else
                        break;
                    case 2:
                        if (incorrectGuesses.isEmpty()) {
                            System.out.println("\nThere are no incorrect Guesses\n");
                        }//end if (incorrectGuesses.isEmpty())

                        else {
                            System.out.println();
                            for (Character character : incorrectGuesses) {
                                System.out.println(character.getName() + " | " + character.getSeries());
                            }//end for (Character character : incorrectGuesses)
                            System.out.println();
                        }//end else
                        break;
                    case 3:
                        if (characterWithHints.isEmpty()) {
                            System.out.println("\nNo hints are currently available to answer.\n");
                        }//end if (characterWithHints.isEmpty())
                        else {
                            System.out.println();
                            for (Character character : characterWithHints) {
                                System.out.println("Hint: " + character.getSeries());
                            }//end for (Character character : characterWithHints)
                            System.out.println();
                        }//end else
                        break;
                    case 4:
                        if (roundCounter == 1 || hintsPerTurn != 1 || player.getHints() == 0 || nextAvailableHint == characters.length) {
                            System.out.println("\nInvalid Input Please try again");
                        }
                        else {
                            System.out.println();
                            for (int i = nextAvailableHint; i < characters.length; i++) {
                                if (!(isCharacterInArrayList(characters[i], correctGuesses))) {
                                    System.out.println("Hint: " + characters[i].getSeries());
                                    player.setHints(player.getHints()-1);
                                    characterWithHints.add(characters[i]);
                                    nextAvailableHint = i+1;
                                    hintsPerTurn++;
                                    break;
                                }//end if (!(isCharacterInArrayList(characters[i], correctGuesses)))
                            }//end for (int i = nextAvailableHint; i < characters.length; i++)
                            System.out.println();
                        }//end else
                        break;
                    default:
                        System.out.println("\nInvalid Input Please try again");
                }//end switch(choice)
            }//end while loop
        }//end if (ranked characters)

        else if (category.equalsIgnoreCase("unranked characters") || category.equalsIgnoreCase("uc")) {
            while (options != -1) {
                if (roundCounter == 1 || hintsPerTurn != 1 || player.getHints() == 0 || nextAvailableHint == characters.length) {
                    System.out.print("Enter 1 to see the correct guesses so far\nEnter 2 to see the incorrect guesses so far\nEnter 3 to see all used hints\nEnter 0 to continue: ");                }
                else {
                    System.out.print("Enter 1 to see the correct guesses so far\nEnter 2 to see the incorrect guesses so far\nEnter 3 to see all used hints\nEnter 4 to use a hint. Hints Remaining: " + player.getHints() + "\nEnter 0 to continue: ");
                }
                choice = validIntInput(scan);

                switch(choice) {
                    case 0:
                        options = -1;
                        System.out.println();
                        break;
                    case 1:
                        if (correctGuesses.isEmpty()) {
                            System.out.println("\nThere are no correct Guesses\n");
                        }//end if (correctGuesses.isEmpty())
                        else {
                            System.out.println();
                            for (Character character : correctGuesses) {
                                System.out.println(character.getName() + " | " + character.getSeries());
                            }//end for (Character character : correctGuesses)
                            System.out.println();
                        }//end else
                        break;
                    case 2:
                        if (incorrectGuesses.isEmpty()) {
                            System.out.println("\nThere are no incorrect Guesses\n");
                        }//end if (incorrectGuesses.isEmpty())
                        else {
                            System.out.println();
                            for (Character character : incorrectGuesses) {
                                System.out.println(character.getName() + " | " + character.getSeries());
                            }//end for (Character character : incorrectGuesses)
                            System.out.println();
                        }//end else
                        break;
                    case 3:
                        if (characterWithHints.isEmpty()) {
                            System.out.println("\nNo hints are currently available to answer.\n");
                        }//end if (characterWithHints.isEmpty())
                        else {
                            System.out.println();
                            for (Character character : characterWithHints) {
                                System.out.println("Hint: " + character.getSeries());
                            }//end for (Character character : characterWithHints)
                            System.out.println();
                        }//end else
                        break;
                    case 4:
                        if (roundCounter == 1 || hintsPerTurn != 1 || player.getHints() == 0 || nextAvailableHint == characters.length) {
                            System.out.println("\nInvalid Input Please try again");
                        }
                        else {
                            System.out.println();
                            for (int i = nextAvailableHint; i < characters.length; i++) {
                                if (!(isCharacterInArrayList(characters[i], correctGuesses))) {
                                    System.out.println("Hint: " + characters[i].getSeries());
                                    player.setHints(player.getHints()-1);
                                    characterWithHints.add(characters[i]);
                                    nextAvailableHint = i+1;
                                    hintsPerTurn++;
                                    break;
                                }//end if (!(isCharacterInArrayList(characters[i], correctGuesses)))
                            }//end for (int i = nextAvailableHint; i < characters.length; i++)
                            System.out.println();
                        }//end else
                        break;
                    default:
                        System.out.println("\nInvalid Input Please try again");
                }//end switch(choice)
            }//end while loop
        }//end else if (unranked characters)

        else {
            System.out.println("Something went wrong ending program");
            System.exit(0);
        }//end else
        hintsPerTurn = 1;
    }//end characterMenuOptions

    public static void animeMenuOptions(Player player, Anime[] listOfAnime, ArrayList<Anime> correctGuesses, ArrayList<Anime> incorrectGuesses, ArrayList<Anime> animeWithHints, String category, Scanner scan) {
        int options = 0;
        int choice;

        if (category.equalsIgnoreCase("ranked anime") || category.equalsIgnoreCase("ra")) {
            while (options != -1) {
                if (roundCounter == 1 || hintsPerTurn != 1 || player.getHints() == 0 || nextAvailableHint == listOfAnime.length) {
                    System.out.print("Enter 1 to see the correct guesses so far\nEnter 2 to see the incorrect guesses so far\nEnter 3 to see all used hints\nEnter 0 to continue: ");
                }
                else {
                    System.out.print("Enter 1 to see the correct guesses so far\nEnter 2 to see the incorrect guesses so far\nEnter 3 to see all used hints\nEnter 4 to use a hint. Hints Remaining: " + player.getHints() + "\nEnter 0 to continue: ");
                }
                choice = validIntInput(scan);

                switch(choice) {
                    case 0:
                        options = -1;
                        System.out.println();
                        break;
                    case 1:
                        if (correctGuesses.isEmpty()) {
                            System.out.println("\nThere are no correct Guesses\n");
                        }//end if (correctGuesses.isEmpty())
                        else {
                            System.out.println();
                            for (Anime anime : correctGuesses) {
                                System.out.println(anime.getRank() + ". " + anime.getName() + " | " + anime.getReleaseYear());
                            }//end for (Anime anime : correctGuesses)
                            System.out.println();
                        }//end else
                        break;
                    case 2:
                        if (incorrectGuesses.isEmpty()) {
                            System.out.println("\nThere are no incorrect Guesses\n");
                        }//end if (incorrectGuesses.isEmpty())
                        else {
                            System.out.println();
                            for (Anime anime : incorrectGuesses) {
                                System.out.println(anime.getName() + " | " + anime.getReleaseYear());
                            }//end for (Anime anime : incorrectGuesses)
                            System.out.println();
                        }//end else
                        break;
                    case 3:
                        if (animeWithHints.isEmpty()) {
                            System.out.println("\nNo hints are currently available to answer.\n");
                        }//end if (animeWithHints.isEmpty())
                        else {
                            System.out.println();
                            for (Anime currentAnime : animeWithHints) {
                                System.out.println("Hint: " + currentAnime.getReleaseYear());
                            }//end for (Anime currentAnime : animeWithHints)
                            System.out.println();
                        }//end else
                        break;
                    case 4:
                        if (roundCounter == 1 || hintsPerTurn != 1 || player.getHints() == 0 || nextAvailableHint == listOfAnime.length) {
                            System.out.println("\nInvalid Input Please try again");
                        }
                        else {
                            System.out.println();
                            for (int i = nextAvailableHint; i < listOfAnime.length; i++) {
                                if (!(isAnimeInArrayList(listOfAnime[i], correctGuesses))) {
                                    System.out.println("Hint: " + listOfAnime[i].getReleaseYear());
                                    player.setHints(player.getHints()-1);
                                    animeWithHints.add(listOfAnime[i]);
                                    nextAvailableHint = i+1;
                                    hintsPerTurn++;
                                    break;
                                }//end if (!(isCharacterInArrayList(characters[i], correctGuesses)))
                            }//end for (int i = nextAvailableHint; i < characters.length; i++)
                            System.out.println();
                        }//end else
                        break;
                    default:
                        System.out.println("\nInvalid Input Please try again");
                }//end switch(choice)
            }//end while loop
        }//end if (ranked anime)

        else if (category.equalsIgnoreCase("unranked anime") || category.equalsIgnoreCase("ua")) {
            while (options != -1) {
                if (roundCounter == 1 || hintsPerTurn != 1 || player.getHints() == 0 || nextAvailableHint == listOfAnime.length) {
                    System.out.print("Enter 1 to see the correct guesses so far\nEnter 2 to see the incorrect guesses so far\nEnter 3 to see all used hints\nEnter 0 to continue: ");
                }
                else {
                    System.out.print("Enter 1 to see the correct guesses so far\nEnter 2 to see the incorrect guesses so far\nEnter 3 to see all used hints\nEnter 4 to use a hint. Hints Remaining: " + player.getHints() + "\nEnter 0 to continue: ");
                }
                choice = validIntInput(scan);

                switch(choice) {
                    case 0:
                        options = -1;
                        System.out.println();
                        break;
                    case 1:
                        if (correctGuesses.isEmpty()) {
                            System.out.println("\nThere are no correct Guesses\n");
                        }//end if (correctGuesses.isEmpty())
                        else {
                            System.out.println();
                            for (Anime anime : correctGuesses) {
                                System.out.println(anime.getName() + " From: " + anime.getReleaseYear());
                            }//end for (Anime anime : correctGuesses)
                            System.out.println();
                        }//end else
                        break;
                    case 2:
                        if (incorrectGuesses.isEmpty()) {
                            System.out.println("\nThere are no incorrect Guesses\n");
                        }//end if (incorrectGuesses.isEmpty())
                        else {
                            System.out.println();
                            for (Anime anime : incorrectGuesses) {
                                System.out.println(anime.getName() + " | " + anime.getReleaseYear());
                            }//end for (Anime anime : incorrectGuesses)
                            System.out.println();
                        }//end else
                        break;
                    case 3:
                        if (animeWithHints.isEmpty()) {
                            System.out.println("\nNo hints are currently available to answer.\n");
                        }//end if (animeWithHints.isEmpty())
                        else {
                            System.out.println();
                            for (Anime currentAnime : animeWithHints) {
                                System.out.println("Hint: " + currentAnime.getReleaseYear());
                            }//end for (Anime currentAnime : animeWithHints)
                            System.out.println();
                        }//end else
                        break;
                    case 4:
                        if (roundCounter == 1 || hintsPerTurn != 1 || player.getHints() == 0 || nextAvailableHint == listOfAnime.length) {
                            System.out.println("\nInvalid Input Please try again");
                        }
                        else {
                            System.out.println();
                            for (int i = nextAvailableHint; i < listOfAnime.length; i++) {
                                if (!(isAnimeInArrayList(listOfAnime[i], correctGuesses))) {
                                    System.out.println("Hint: " + listOfAnime[i].getReleaseYear());
                                    player.setHints(player.getHints()-1);
                                    animeWithHints.add(listOfAnime[i]);
                                    nextAvailableHint = i+1;
                                    hintsPerTurn++;
                                    break;
                                }//end if (!(isCharacterInArrayList(characters[i], correctGuesses)))
                            }//end for (int i = nextAvailableHint; i < characters.length; i++)
                            System.out.println();
                        }//end else
                        break;
                    default:
                        System.out.println("\nInvalid Input Please try again");
                }//end switch(choice)
            }//end while loop
        }//end else if (unranked anime)

        else {
            System.out.println("Something went wrong ending program");
            System.exit(0);
        }//end else
        hintsPerTurn = 1;
    }//end animeMenuOptions

    public static void videoGameMenuOptions(Player player, VideoGame[] listOfVideoGames,ArrayList<VideoGame> correctGuesses, ArrayList<VideoGame> incorrectGuesses, ArrayList<VideoGame> videoGamesWithHints,String category, Scanner scan) {
        int options = 0;
        int choice;

        if (category.equalsIgnoreCase("ranked video games") || category.equalsIgnoreCase("rvg")) {
            while (options != -1) {
                if (roundCounter == 1 || hintsPerTurn != 1 || player.getHints() == 0 || nextAvailableHint == listOfVideoGames.length) {
                    System.out.print("Enter 1 to see the correct guesses so far\nEnter 2 to see the incorrect guesses so far\nEnter 3 to see all used hints\nEnter 0 to continue: ");
                }
                else {
                    System.out.print("Enter 1 to see the correct guesses so far\nEnter 2 to see the incorrect guesses so far\nEnter 3 to see all used hints\nEnter 4 to use a hint. Hints Remaining: " + player.getHints() + "\nEnter 0 to continue: ");
                }
                choice = validIntInput(scan);
                switch(choice) {
                    case 0:
                        options = -1;
                        System.out.println();
                        break;
                    case 1:
                        if (correctGuesses.isEmpty()) {
                            System.out.println("\nThere are no correct Guesses\n");
                        }//end if (correctGuesses.isEmpty())
                        else {
                            System.out.println();
                            for (VideoGame currentVideoGame : correctGuesses) {
                                System.out.println(currentVideoGame.getRank() + ". " + currentVideoGame.getName() + " | " + currentVideoGame.getReleaseYear());
                            }//end for (VideoGame currentVideoGame : correctGuesses)
                            System.out.println();
                        }//end else
                        break;
                    case 2:
                        if (incorrectGuesses.isEmpty()) {
                            System.out.println("\nThere are no incorrect Guesses\n");
                        }//end if (incorrectGuesses.isEmpty())
                        else {
                            System.out.println();
                            for (VideoGame currentVideoGame : incorrectGuesses) {
                                System.out.println(currentVideoGame.getName() + " | " + currentVideoGame.getReleaseYear());
                            }//end for (VideoGame currentVideoGame : incorrectGuesses)
                            System.out.println();
                        }//end else
                        break;
                    case 3:
                        if (videoGamesWithHints.isEmpty()) {
                            System.out.println("\nNo hints are currently available to answer.\n");
                        }//end if (videoGamesWithHints.isEmpty())
                        else {
                            System.out.println();
                            for (VideoGame currentVideoGame: videoGamesWithHints) {
                                System.out.println("Hint: " + currentVideoGame.getReleaseYear());
                            }//end for (VideoGame currentVideoGame: videoGamesWithHints)
                            System.out.println();
                        }//end else
                        break;
                    case 4:
                        if (roundCounter == 1 || hintsPerTurn != 1 || player.getHints() == 0 || nextAvailableHint == listOfVideoGames.length) {
                            System.out.println("\nInvalid Input Please try again");
                        }
                        else {
                            System.out.println();
                            for (int i = nextAvailableHint; i < listOfVideoGames.length; i++) {
                                if (!(isVideoGameInArrayList(listOfVideoGames[i], correctGuesses))) {
                                    System.out.println("Hint: " + listOfVideoGames[i].getReleaseYear());
                                    player.setHints(player.getHints()-1);
                                    videoGamesWithHints.add(listOfVideoGames[i]);
                                    nextAvailableHint = i+1;
                                    hintsPerTurn++;
                                    break;
                                }//end if (!(isCharacterInArrayList(characters[i], correctGuesses)))
                            }//end for (int i = nextAvailableHint; i < characters.length; i++)
                            System.out.println();
                        }//end else
                        break;
                    default:
                        System.out.println("\nInvalid Input Please try again");
                }//end switch(choice)
            }//end while loop
        }//end if (ranked video games)

        else if (category.equalsIgnoreCase("unranked video games") || category.equalsIgnoreCase("uvg")) {
            while (options != -1) {
                if (roundCounter == 1 || hintsPerTurn != 1 || player.getHints() == 0 || nextAvailableHint == listOfVideoGames.length) {
                    System.out.print("Enter 1 to see the correct guesses so far\nEnter 2 to see the incorrect guesses so far\nEnter 3 to see all used hints\nEnter 0 to continue: ");
                }
                else {
                    System.out.print("Enter 1 to see the correct guesses so far\nEnter 2 to see the incorrect guesses so far\nEnter 3 to see all used hints\nEnter 4 to use a hint. Hints Remaining: " + player.getHints() + "\nEnter 0 to continue: ");
                }
                choice = validIntInput(scan);

                switch(choice) {
                    case 0:
                        options = -1;
                        System.out.println();
                        break;
                    case 1:
                        if (correctGuesses.isEmpty()) {
                            System.out.println("\nThere are no correct Guesses\n");
                        }//end if (correctGuesses.isEmpty())
                        else {
                            System.out.println();
                            for (VideoGame currentVideoGame : correctGuesses) {
                                System.out.println(currentVideoGame.getName() + " | " + currentVideoGame.getReleaseYear());
                            }//end for (VideoGame currentVideoGame : correctGuesses)
                            System.out.println();
                        }//end else
                        break;
                    case 2:
                        if (incorrectGuesses.isEmpty()) {
                            System.out.println("\nThere are no incorrect Guesses\n");
                        }//end if (incorrectGuesses.isEmpty())
                        else {
                            System.out.println();
                            for (VideoGame currentVideoGame : incorrectGuesses) {
                                System.out.println(currentVideoGame.getName() + " | " + currentVideoGame.getReleaseYear());
                            }//end for (VideoGame currentVideoGame : incorrectGuesses)
                            System.out.println();
                        }//end else
                        break;
                    case 3:
                        if (videoGamesWithHints.isEmpty()) {
                            System.out.println("\nNo hints are currently available to answer.\n");
                        }//end if (videoGamesWithHints.isEmpty())
                        else {
                            System.out.println();
                            for (VideoGame currentVideoGame: videoGamesWithHints) {
                                System.out.println("Hint: " + currentVideoGame.getReleaseYear());
                            }//end for (VideoGame currentVideoGame: videoGamesWithHints)
                            System.out.println();
                        }//end else
                        break;
                    case 4:
                        if (roundCounter == 1 || hintsPerTurn != 1 || player.getHints() == 0 || nextAvailableHint == listOfVideoGames.length) {
                            System.out.println("\nInvalid Input Please try again");
                        }
                        else {
                            System.out.println();
                            for (int i = nextAvailableHint; i < listOfVideoGames.length; i++) {
                                if (!(isVideoGameInArrayList(listOfVideoGames[i], correctGuesses))) {
                                    System.out.println("Hint: " + listOfVideoGames[i].getReleaseYear());
                                    player.setHints(player.getHints()-1);
                                    videoGamesWithHints.add(listOfVideoGames[i]);
                                    nextAvailableHint = i+1;
                                    hintsPerTurn++;
                                    break;
                                }//end if (!(isCharacterInArrayList(characters[i], correctGuesses)))
                            }//end for (int i = nextAvailableHint; i < characters.length; i++)
                            System.out.println();
                        }//end else
                        break;
                    default:
                        System.out.println("\nInvalid Input Please try again");
                }//end switch(choice)
            }//end while loop
        }//end else if (unranked video game)

        else {
            System.out.println("Something went wrong ending program");
            System.exit(0);
        }//end else
        hintsPerTurn = 1;
    }//end videoGameMenuOptions

    /*****************************************************************************************************************/
    //Checker Methods

    private static boolean isYesOrNo(String input) {
        boolean checker = false;
        // Convert the input to lowercase and compare
        String lowerCaseInput = input.toLowerCase();

        if ((lowerCaseInput.equalsIgnoreCase("yes") || lowerCaseInput.equalsIgnoreCase("y") || lowerCaseInput.equalsIgnoreCase("no") || lowerCaseInput.equalsIgnoreCase("n"))) {
            checker = true;
        }
        return checker;
    }//end isYesOrNo

    public static boolean isCharacterInArray(Character[] characters, String name, String series) {
        boolean checker = false;
        for (Character character : characters) {
            if (character.getName().equalsIgnoreCase(name) && character.getSeries().equalsIgnoreCase(series)) {
                checker = true; //turns to true if the character being guessed is found in the array
                break; //end the for loop if the character has been found
            }//end if
        }//end for (Character character : characters)

        return checker;
    }//end isCharacterInArray

    public static boolean isCharacterInArrayList(Character character, ArrayList<Character> correctGuesses) {
        boolean checker = false;
        for (Character currentCharacter : correctGuesses) {
            if (currentCharacter.getName().equalsIgnoreCase(character.getName()) && currentCharacter.getSeries().equalsIgnoreCase(character.getSeries())) {
                checker = true;
                break;
            }
        }
        return checker;
    }//end isCharacterInArrayList

    public static boolean isAnimeInArray(Anime[] anime, String name, String releaseYear) {
        boolean checker = false;
        for (Anime currentAnime : anime) {
            if (currentAnime.getName().equalsIgnoreCase(name) && currentAnime.getReleaseYear().equalsIgnoreCase(releaseYear)) {
                checker = true; //turns to true if the anime being guessed is found in the array
                break; //end the for loop if the character has been found
            }//end if
        }//end for (Anime currentAnime : anime)

        return checker;
    }//end isAnimeInArray

    public static boolean isAnimeInArrayList(Anime anime, ArrayList<Anime> correctGuesses) {
        boolean checker = false;
        for (Anime currentAnime : correctGuesses) {
            if (currentAnime.getName().equalsIgnoreCase(anime.getName()) && currentAnime.getReleaseYear().equalsIgnoreCase(anime.getReleaseYear())) {
                checker = true;
                break;
            }
        }
        return checker;
    }//end isAnimeInArrayList

    public static boolean isVideoGameInArray(VideoGame[] videoGames, String name, String releaseYear) {
        boolean checker = false;
        for (VideoGame currentVideoGame : videoGames) {
            if (currentVideoGame.getName().equalsIgnoreCase(name) && currentVideoGame.getReleaseYear().equalsIgnoreCase(releaseYear)) {
                checker = true; //turns to true if the video game being guessed is found in the array
                break;
            }//end if
        }//end for (VideoGame currentVideoGame : videoGames)

        return checker;
    }//end isVideoGameInArray

    public static boolean isVideoGameInArrayList(VideoGame videoGame, ArrayList<VideoGame> correctGuesses) {
        boolean checker = false;
        for (VideoGame currentVideoGame : correctGuesses) {
            if (currentVideoGame.getName().equalsIgnoreCase(videoGame.getName()) && currentVideoGame.getReleaseYear().equalsIgnoreCase(videoGame.getReleaseYear())) {
                checker = true;
                break;
            }
        }
        return checker;
    }//end isVideoGameInArrayList

    public static boolean isCharacterGuessARepeat(ArrayList<Character> correctGuesses, ArrayList<Character> incorrectGuesses, String name, String series) {
        for (Character character : correctGuesses) {
            if (character.getName().equalsIgnoreCase(name) && character.getSeries().equalsIgnoreCase(series)) {
                return true;
            }//end if
        }//end for

        for (Character character : incorrectGuesses) {
            if (character.getName().equalsIgnoreCase(name) && character.getSeries().equalsIgnoreCase(series)) {
                return true;
            }//end if
        }//end for
        return false;
    }//end isCharacterGuessARepeat

    public static boolean isAnimeGuessARepeat(ArrayList<Anime> correctGuesses, ArrayList<Anime> incorrectGuesses, String name, String releaseYear) {
        for (Anime currentAnime: correctGuesses) {
            if (currentAnime.getName().equalsIgnoreCase(name) && currentAnime.getReleaseYear().equalsIgnoreCase(releaseYear)) {
                return true;
            }//end if
        }//end for

        for (Anime currentAnime: incorrectGuesses) {
            if (currentAnime.getName().equalsIgnoreCase(name) && currentAnime.getReleaseYear().equalsIgnoreCase(releaseYear)) {
                return true;
            }//end if
        }//end for
        return false;
    }//end isAnimeGuessARepeat

    public static boolean isVideoGameGuessARepeat(ArrayList<VideoGame> correctGuesses, ArrayList<VideoGame> incorrectGuesses, String name, String releaseYear) {
        for (VideoGame videoGame : correctGuesses) {
            if (videoGame.getName().equalsIgnoreCase(name) && videoGame.getReleaseYear().equalsIgnoreCase(releaseYear)) {
                return true;
            }//end if
        }//end for

        for (VideoGame videoGame : incorrectGuesses) {
            if (videoGame.getName().equalsIgnoreCase(name) && videoGame.getReleaseYear().equalsIgnoreCase(releaseYear)) {
                return true;
            }//end if
        }//end for
        return false;
    }//end isVideoGameGuessARepeat

    /*****************************************************************************************************************/
    //Validation Methods

    public static String validAnswer(Scanner scan) {
        String userInput = "";
        boolean validInput = false;
        System.out.print("Enter yes/y or no/n: ");
        while (!validInput) {
            userInput = scan.nextLine();
            if (isYesOrNo(userInput)) {
                validInput = true;
            }//end if (isYesOrNo(userInput))
            else {
                System.out.print("Invalid input\nPlease enter yes/y or no/n: ");
            }//end else
        }//while loop
        return userInput;
    }//end validAnswer

    public static int validIntInput(Scanner scan) {
        boolean success = false; //used to end while loop
        int validInput = 0; //initialize validInput

        while (!success) {
            //tries to turn the user input into another
            try {
                validInput = Integer.parseInt(scan.next());
                success = true;
                //catches the mistake of the input not being a number and prompts user to try again
            } catch (NumberFormatException e) {
                System.out.print("Invalid Input. Please enter a number: ");
                scan.nextLine();
            }//end try catch
        }//end while loop

        return validInput;
    }//end validIntInput

    public static String validPlayerName(ArrayList<String> names, int currentPlayer,Scanner scan) {
        String name = ""; //initialize the name
        boolean checker = true; //used to end while loop
        System.out.print("Enter the name of player " + (currentPlayer + 1) + ": ");
        scan.nextLine(); // Consume the newline character

        while (checker) {
            name = scan.nextLine();
            if (!names.contains(name)) {
                checker = false; //ends loop when valid name is found

            }//end if (!names.contains(name))

            else {
                //Message tells user name has already been used
                System.out.print("Name has already been used. Please enter a different name: ");
            }//end else
        }//end if (placement > 0 && placement <= numOfPlayers)

        return name;
    }//end validPlayerName

    public static int validPlacement(ArrayList<Integer> placements, int numOfPlayers, Scanner scan) {
        int placement = 0; //initialize the placement
        boolean checker = true; //used to end while loop
        System.out.print("Enter the placement (placement at the end of the jeopardy) of the player: ");

        while (checker) {
            placement = validIntInput(scan); //checks for valid int input

            //ensure that the placement is within the range 0 to number of players inclusive
            if (placement > 0 && placement <= numOfPlayers) {
                //checks to see if the placement has not already been assigned to another player
                if (!placements.contains(placement)) {
                    checker = false; //ends loop when valid placement is found
                }//end if (!placements.contains(placement))

                else {
                    //Message tells user placement has already been used
                    System.out.print("Placement has already been used. Please enter a different placement: ");
                }//end else
            }//end if (placement > 0 && placement <= numOfPlayers)

            else {
                //Message telling using that the number entered for placement is outside of Range
                System.out.print("Invalid placement (Outside of Range). Please enter a valid placement: ");
            }//end else

        }//end while loop

        return placement;
    }//end validPlacement

    public static int validPosition(ArrayList<Integer> positions, int numOfPlayers, Scanner scan) {
        int position = 0; //initialize the position
        boolean checker = true; //used to end while loop
        System.out.print("Enter the position (turn order of the final Jeopardy) of the player: ");

        while (checker) {

            position = validIntInput(scan); //checks for valid int input

            //ensure that the position is within the range 0 to number of players inclusive
            if (position > 0 && position <= numOfPlayers) {
                //checks to see if the position has not already been assigned to another player
                if (!positions.contains(position)) {
                    checker = false; //ends loop when valid position is found
                }//end if (!positions.contains(position))

                else {
                    //Message tells user position has already been used
                    System.out.print("Position has already been used. Please enter a different position: ");
                }//end else
            }//end if (position > 0 && position <= numOfPlayers)

            else {
                //Message telling using that the number entered for position is outside of Range
                System.out.print("Invalid position (Outside of Range). Please enter a valid position: ");
            }//end else
        }//end while loop

        return position;
    }//end validPosition

    public static String validCategory(String[] validCategories,Scanner scan) {
        String category = ""; //Initialize String
        System.out.println("What is the category theme of your final jeopardy?");
        System.out.print("Options: Ranked/Unranked of each type: Characters (rc/uc), Anime (ra/ua), or Video games (rvg/uvg): ");
        scan.nextLine();

        boolean checker = true; //used to end while loop

        while (checker) {
            category = scan.nextLine().toLowerCase(); // Convert the input to lowercase for case-insensitive comparison

            //loops through the array hold all valid Categories and their abbreviations to see if the inputted value is one of them
            for (String validCategory : validCategories) {
                if (category.equalsIgnoreCase(validCategory)) {
                    checker = false; //change checker to end while loop
                    break; //once a valid category is found stop the for loop
                }//end if (category.equalsIgnoreCase(validCategory))
            }//end for (String validCategory : validCategories)

            //assuming the input goes through the entire loop, checker will not have changed
            //prints out statements saying invalid category and provides the valid inputs
            if (checker) {
                System.out.println("Invalid category. Please choose from the provided options.");
                System.out.print("Options: Ranked r/Unranked u of each type: Characters (rc/uc), Anime (ra/ua), or Video games (rvg/uvg): ");
            }//end if (checker)
        }//end while (checker)

        return category;
    }//end choiceCategory

    public static int validRank(ArrayList<Integer> rankingsAlreadyUsed, int numOfAnswers, Scanner scan) {
        int rank = 0; //initializes rank
        boolean checker = true; //used to end while loop
        System.out.print("Enter the their/its rank: ");
        while (checker) {
            rank = validIntInput(scan); //ensure valid int input is stored in rank

            //checks to ensure that inputted ranked is within valid range based on number of
            if (rank > 0 && rank <= numOfAnswers) {
                //checks to ensure the rank has not already been assigned to another answer
                if (!rankingsAlreadyUsed.contains(rank)) {
                    checker = false; //ends loop once valid input is inputted
                }//end if (!rankingsAlreadyUsed.contains(rank))

                else {
                    //Tells user that the inputted rank has already been assigned
                    System.out.print("Rank has already been used. Please enter a different rank: ");
                }//end else
            }//end if (rank > 0 && rank <= numOfAnswers)

            else {
                //Tells user the rank is outside the valid range
                System.out.print("Invalid rank (Outside of Range). Please enter a valid rank: ");
            }//end else
        }//end while loop

        return rank;
    }//end validRank

    /***************************************************************************************************************/
    //Add Methods

    public static void addPlayerName(ArrayList<String> namesAlreadyUsed, String name) {
        namesAlreadyUsed.add(name);
    }//end addPlayerName

    public static void addPlacement(ArrayList<Integer> placementsAlreadyUsed, int placements) {
        placementsAlreadyUsed.add(placements); //adds the valid inputted placement to ArrayList that stores used placements
    }//end addPlacement

    public static void addPosition(ArrayList<Integer> positionsAlreadyUsed, int position) {
        positionsAlreadyUsed.add(position); //adds the valid inputted position to ArrayList that stores used positions
    }//end addPosition

    public static void addRank(ArrayList<Integer> rankingsAlreadyUsed, int rank) {
        rankingsAlreadyUsed.add(rank); //adds the valid inputted rank to ArrayList that stores used ranks
    }//end addRank

    public static void addCorrectCharacterGuess(ArrayList<Character> correctGuesses, Character character) {
        correctGuesses.add(character);//adds the character to correctGuesses
    }//end addCorrectCharacterGuess

    public static void addIncorrectCharacterGuesses(ArrayList<Character> incorrectGuesses,  String name, String series) {
        Character character = new Character(name, series);
        incorrectGuesses.add(character);
    }//end addIncorrectCharacterGuesses

    public static void addCorrectAnimeGuess(ArrayList<Anime> correctGuesses, Anime anime) {
        correctGuesses.add(anime);
    }//end addCorrectAnimeGuess

    public static void addIncorrectAnimeGuesses(ArrayList<Anime> incorrectGuesses, String name, String releaseYear) {
        Anime anime = new Anime(name, releaseYear);
        incorrectGuesses.add(anime);
    }//end addIncorrectAnimeGuesses

    public static void addCorrectVideoGameGuess(ArrayList<VideoGame> correctGuesses, VideoGame videoGame) {
        correctGuesses.add(videoGame);
    }//end addCorrectVideoGameGuess

    public static void addIncorrectVideoGameGuesses(ArrayList<VideoGame> incorrectGuesses, String name, String releaseYear) {
        VideoGame videoGame = new VideoGame(name, releaseYear);
        incorrectGuesses.add(videoGame);
    }//end addIncorrectVideoGameGuesses

    /***************************************************************************************************************/
    //Sort Methods

    public static void sortPlayerArray(Player[] players) {
        Arrays.sort(players, new PlayerPositionComparator()); //sorts the array based on position
    }//end sortPlayerArray

    public static void SortCharacterArray(Character[] characters) {
        Arrays.sort(characters, new CharacterRankComparator()); //sorts the array based on rank
    }//end sortCharacterArray

    public static void SortAnimeArray(Anime[] anime) {
        Arrays.sort(anime, new AnimeRankComparator()); //sorts the array based rank
    }//end  SortAnimeArray

    public static void SortVideoGameArray(VideoGame[] videoGames) {
        Arrays.sort(videoGames, new VideoGameComparator()); //sorts the array based rank
    }//end SortVideoGameArray

    public static void sortCorrectCharacterGuesses(ArrayList<Character> correctGuesses) {
        correctGuesses.sort(new CharacterRankComparator());
    }//end sortCorrectCharacterGuesses

    public static void sortCorrectAnimeGuesses(ArrayList<Anime> correctGuesses) {
        correctGuesses.sort(new AnimeRankComparator());
    }//end sortCorrectAnimeGuesses

    public static void sortCorrectVideoGameGuesses(ArrayList<VideoGame> correctGuesses) {
        correctGuesses.sort(new VideoGameComparator());
    }//end sortCorrectVideoGameGuesses

    /***************************************************************************************************************/
    //Get Methods

    public static Character getCorrectCharacter(Character[] characters, String name, String series) {
        for (Character character : characters) {
            if (character.getName().equalsIgnoreCase(name) && character.getSeries().equalsIgnoreCase(series)) {
                return character;
            }//end if
        }//end for (Character currentCharacter : characters)
        return null;
    }//end  getCharacter

    public static Anime getCorrectAnime(Anime[] anime, String name, String releaseYear) {
        for (Anime currentAnime : anime) {
            if (currentAnime.getName().equalsIgnoreCase(name) && currentAnime.getReleaseYear().equalsIgnoreCase(releaseYear)) {
                return currentAnime;
            }//end if
        }//end for (Anime currentAnime : anime)
        return null;
    }//end getCorrectAnime

    public static VideoGame getCorrectVideoGame(VideoGame[] videoGames, String name, String releasedYear) {
        for (VideoGame currentVideoGame : videoGames) {
            if (currentVideoGame.getName().equalsIgnoreCase(name) && currentVideoGame.getReleaseYear().equalsIgnoreCase(releasedYear)) {
                return currentVideoGame;
            }//end if
        }//end for (VideoGame currentVideoGame : videoGames)
        return null;
    }//end getCorrectVideoGame

    /***************************************************************************************************************/
    //Update Methods

    public static void updateLives(Player player) {
        player.setLives(player.getLives() - 1);
    }//end updateLives

    public static int updateRemainingPlayers(Player[] players) {
        int numberOfPlayersWithLives = 0;
        for (Player currentPlayer : players) {
            if (currentPlayer.getLives() != 0) {
                numberOfPlayersWithLives++;
            }//end if (currentPlayer.getLives() > 0)
        }//end or (Player currentPlayer : players)
        return numberOfPlayersWithLives;
    }//end updateRemainingPlayers

    /***************************************************************************************************************/
    //Assign Winner Method

    public static String assignWinner(Player[] players) {
        String winner = "";
        if (checkForTie(players)) {
            winner = "It's a tie between: ";
            for (Player player : players) {
                if (player.getLives() != 0) {
                    winner = winner.concat(player.getName());
                    winner = winner.concat(", ");
                }//end if (player.getLives() != 0)
            }//end for (Player player : players)
            winner = winner.substring(0, winner.length() - 2);
        }//end if (checkForTie(players))

        else {
            for (Player player : players) {
                if (player.getLives() != 0) {
                    winner = "The winner is: " + player.getName();
                    break;
                }//end if (player.getLives() != 0)
            }//end for (Player player : players)
        }//end else
        return winner;
    }//end assignWinner

    /***************************************************************************************************************/
    //Check for tie Method

    public static boolean checkForTie(Player[] players) {
        int tieChecker = 0;
        boolean tie = false;
        for (Player player : players) {
            if (player.getLives() != 0) {
                tieChecker++;
            }//end if (player.getLives() != 0)
        }//end for (Player player : players)
        if (tieChecker > 1) {
            tie = true;
        }//end if (tieChecker > 1)
        return tie;
    }//end checkForTie

    /***************************************************************************************************************/
    //Print Players

    public static void printPlayers(Player[] players) {
        System.out.println();
        for (Player player : players) {
            System.out.println(player);
        }//end for (Player player : players)
        System.out.println();
    }//end printPlayers

}//end Class Main