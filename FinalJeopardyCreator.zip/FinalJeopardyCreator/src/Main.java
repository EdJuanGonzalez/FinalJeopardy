import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;


public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static ArrayList<Player> players;
    private static ArrayList<Anime> answerListA;
    private static ArrayList<Character> answerListC;
    private static ArrayList<VideoGame> answerListV;
    private static ArrayList<Anime> correctGuessesA;
    private static ArrayList<Character> correctGuessesC;
    private static ArrayList<VideoGame> correctGuessesV;
    private static ArrayList<Anime> incorrectGuessesA;
    private static ArrayList<Character> incorrectGuessesC;
    private static ArrayList<VideoGame> incorrectGuessesV;
    private static ArrayList<Anime> activeHintsA;
    private static ArrayList<Character> activeHintsC;
    private static ArrayList<VideoGame> activeHintsV;
    private static int categoryID = 0;
    private static int playersLeft;
    private static final String ANSI_RED = "\u001B[1;31m";
    private static final String ANSI_GREEN = "\u001B[1;32m";
    public static final String ANSI_RESET = "\u001B[1;39m";
    public static final String ANSI_YELLOW = "\u001B[1;33m";

    public static void main(String[] args) {
        setupGame();
        startFinalJeopardy();
    }

    //setup functions
    public static void setupGame() {
        setupAnswers();
        setupPlayers();
    }

    public static void setupAnswers() {
        final String[] categories = {"Anime", "a", "Character", "c", "Video Game", "v"};
        System.out.print(ANSI_RESET +"Jeopardy category: Anime/a, Character/c, Video Game/v: ");
        String categoryType = validInput(categories);

        if (categoryType.equalsIgnoreCase("quit")) System.exit(1);
        switch (categoryType.toLowerCase()) {
            case "anime":
            case "a":
                categoryID = 1;
                break;
            case "character":
            case "c":
                categoryID = 2;
                break;
            case "video game":
            case "v":
                categoryID = 3;
                break;
            default:
                System.out.println("Invalid category!");
                System.exit(1);
        }

        System.out.println("Enter answers for the category.");
        System.out.print("Do you have a CSV file containing answers (yes/y or no/n): ");
        String yn = validInput(new String[]{"yes", "y", "no", "n"});

        if (yn.equalsIgnoreCase("quit")) System.exit(1);

        System.out.print("How many unique answers do you have: ");
        int numOfAnswers = validIntInput();
        if (numOfAnswers == -1) System.exit(1);

        List<String> answers = new ArrayList<>();
        if (yn.equalsIgnoreCase("yes") || yn.equalsIgnoreCase("y")) {
            String path = "answerfile/";
            System.out.println("Please make sure that the file is in the answerFile Folder");
            System.out.print("Please enter the name of the file: ");
            String fileName = sc.nextLine().trim();
            path = path.concat(fileName);
            int success = createAnswerList(answers, path, numOfAnswers, 0);
            if (success == 0) System.exit(1);
        }
        else {
            int success = createAnswerList(answers, null, numOfAnswers, 1);
            if (success == 0) System.exit(1);
        }

        switch (categoryID) {
            case 1:
                answerListA = new ArrayList<>();
                createAnswerObjects(answers, numOfAnswers);
                break;
            case 2:
                answerListC = new ArrayList<>();
                createAnswerObjects(answers, numOfAnswers);
                break;
            case 3:
                answerListV = new ArrayList<>();
                createAnswerObjects(answers, numOfAnswers);
                break;
            default:
                System.out.println("Invalid category!");
                System.exit(1);
        }
    }

    public static void setupPlayers() {
        System.out.print("How many players are in the final jeopardy: ");
        int participants = validIntInput();
        if (participants < 2) {
            System.out.println("Invalid number of players!");
            System.out.print("Please enter a number greater than 1");
            participants = validIntInput();
        }
        players = new ArrayList<>();
        createPlayers(participants);
        players.sort(Comparator.comparingInt(Player::getPosition));
        ArrayList<Player> sortedPlayers = new ArrayList<>();
        for (Player player : players) {
            sortedPlayers.add(player.getPosition() - 1, player);
        }
        players = sortedPlayers;
    }

    //start functions
    public static void startFinalJeopardy() {
        switch(categoryID) {
            case 1:
                animeFinalJeopardy();
                break;
            case 2:
                characterFinalJeopardy();
                break;
            case 3:
                videoGameFinalJeopardy();
                break;
            default:
                break;
        }
    }

    public static void animeFinalJeopardy() {
        playersLeft = players.size();
        correctGuessesA = new ArrayList<>();
        incorrectGuessesA = new ArrayList<>();
        activeHintsA = new ArrayList<>();
        while (playersLeft > 1 && correctGuessesA.size() != answerListA.size()) {
            for (Player player : players) {
                if (player.getIsIn() && player.getLives() > 0) {
                    boolean correct = takeATurn(player);
                    if (correct) System.out.println(ANSI_GREEN + "\nCorrect Guess" + ANSI_RESET);
                    else {
                        System.out.println(ANSI_RED + "\nIncorrect Guess" + ANSI_RESET);
                        player.setLives(player.getLives() - 1);
                        if (player.getLives() == 0) System.out.println(player.getName() + " is out");
                        else System.out.println(player.getName() + " has " + player.getLives() + " live(s)");
                    }
                }
                if (player.getLives() == 0 && player.getIsIn()) {
                    player.setIsIn(false);
                    playersLeft--;
                }
                if (playersLeft == 1) break;
            }
        }
        if (playersLeft == 1) System.out.println("The Winner is " + players.getFirst().getName());
        else {
            System.out.println("It's a tie between");
            for (Player player : players) System.out.println(player.getName());
        }
    }

    public static void characterFinalJeopardy() {
        playersLeft = players.size();
        correctGuessesC = new ArrayList<>();
        incorrectGuessesC = new ArrayList<>();
        activeHintsC = new ArrayList<>();
        while (playersLeft > 1 && correctGuessesC.size() != answerListC.size()) {
            for (Player player : players) {
                if (player.getIsIn() && player.getLives() > 0) {
                    boolean correct = takeATurn(player);
                    if (correct) System.out.println(ANSI_GREEN + "\nCorrect Guess" + ANSI_RESET);
                    else {
                        System.out.println(ANSI_RED + "\nIncorrect Guess" + ANSI_RESET);
                        player.setLives(player.getLives() - 1);
                        if (player.getLives() == 0) System.out.println(player.getName() + " is out");
                        else System.out.println(player.getName() + " has " + player.getLives() + " live(s)");
                    }
                }
                if (player.getLives() == 0 && player.getIsIn()) {
                    player.setIsIn(false);
                    playersLeft--;
                }
                if (playersLeft == 1) break;
            }
        }
        if (playersLeft == 1) System.out.println("The Winner is " + players.getFirst().getName());
        else {
            System.out.println("It's a tie between");
            for (Player player : players) System.out.println(player.getName());
        }
    }

    public static void videoGameFinalJeopardy() {
        playersLeft = players.size();
        correctGuessesV = new ArrayList<>();
        incorrectGuessesV = new ArrayList<>();
        activeHintsV = new ArrayList<>();
        while (playersLeft > 1 && correctGuessesV.size() != answerListV.size()) {
            for (Player player : players) {
                if (player.getIsIn() && player.getLives() > 0) {
                    boolean correct = takeATurn(player);
                    if (correct) System.out.println(ANSI_GREEN + "\nCorrect Guess" + ANSI_RESET);
                    else {
                        System.out.println(ANSI_RED + "\nIncorrect Guess" + ANSI_RESET);
                        player.setLives(player.getLives() - 1);
                        if (player.getLives() == 0) System.out.println(player.getName() + " is out");
                        else System.out.println(player.getName() + " has " + player.getLives() + " live(s)");
                    }
                }
                if (player.getLives() == 0 && player.getIsIn()) {
                    player.setIsIn(false);
                    playersLeft--;
                }
                if (playersLeft == 1) break;
            }
        }
        if (playersLeft == 1) System.out.println("The Winner is " + players.getFirst().getName());
        else {
            System.out.println("It's a tie between");
            for (Player player : players) System.out.println(player.getName());
        }
    }

    //Turn Execution Functions
    public static boolean takeATurn(Player player) {
        System.out.println("\nPlayer Turn: " + player.getName());
        System.out.println("Lives: " + player.getLives());
        System.out.println("Hints: " + player.getHints());
        while (true) {
            int decision = menuOptions();
            int continueToGuess = executeOption(player, decision);
            if (continueToGuess == 1) break;
        }
        String name;
        String attribute;
        System.out.print("Enter Guess & Attribute separated by a comma: ");
        while (true) {
            String input = sc.nextLine();
            String[] parts = input.split(",", 2);
            if (parts.length != 2) {
                System.out.print("Invalid input format. Please enter both name and attribute separated by a space: ");
                continue;
            }
            name = parts[0];
            attribute = parts[1];
            if (!repeatGuess(name, attribute)) break;
            else System.out.print("Repeat Answer Please Try again: ");
        }

        return checkGuess(name, attribute);
    }

    private static int menuOptions() {
        int input;
        while (true) {
            System.out.println("""
                \nPlease enter one of the following numbers:
                1: To guess
                2: To Check Correct Guesses
                3: To Check Incorrect Guesses
                4: To Check Current Active Hints
                5: To Use a hint
                6: Host Fix Mistake
                """);
            System.out.print("Enter Number for Decision: ");
            input = validIntInput();
            if (input >= 1 && input <= 6) break;
            else System.out.println("Invalid Input Please pick an option 1-5");
        }
        return input;
    }

    private static int executeOption(Player player, int decision) {
        int result = 0;
        switch(decision) {
            case 1:
                result = 1;
                break;
            case 2:
                getCorrectGuesses();
                break;
            case 3:
                getIncorrectGuesses();
                break;
            case 4:
                getActiveHints();
                break;
            case 5:
                useHint(player);
                break;
            case 6:
                hostOptions();
                System.out.println("\nPlayer Turn: " + player.getName());
                System.out.println("Lives: " + player.getLives());
                System.out.println("Hints: " + player.getHints());
            default:
                break;
        }
        return result;
    }

    private static void hostOptions() {
        int input;
        while (true) {
            System.out.println("""
                    \nPlease enter one of the following numbers
                    1: To continue
                    2: update lives
                    3: update answers
                    """);
            System.out.print("Enter Number for Decision: ");
            input = validIntInput();
            if (input>=2 && input <= 3) {
                executeHostOption(input);
            }
            else if (input == 1) break;
            else System.out.println("Invalid Input Please pick an option 1-3");
        }
    }

    private static void executeHostOption(int input) {
        switch(input) {
            case 2:
                while (true) {
                    System.out.print("Enter the name of the player who's lives need adjusting: ");
                    String name = sc.nextLine().trim();
                    int playerIndex = -1;
                    for (int i = 0; i < players.size(); i++) {
                        if (name.replaceAll("\\s", "").equalsIgnoreCase(players.get(i).getName().replaceAll("\\s", ""))) {
                            playerIndex = i;
                            break;
                        }
                    }
                    if (playerIndex == -1) System.out.println("No Player with that name. Please try again");
                    else {
                        System.out.print("What is the new lives total of player " + players.get(playerIndex).getName() + ": ");
                        int newLiveTotal = validIntInput();
                        players.get(playerIndex).setLives(newLiveTotal);
                        if (players.get(playerIndex).getLives() > 0 && !players.get(playerIndex).getIsIn()) {
                            players.get(playerIndex).setIsIn(true);
                            playersLeft++;
                        }
                        break;
                    }
                }
                break;
            case 3:
                while (true) {
                    boolean end = false;
                    System.out.println("""
                            \nPlease enter one of the following numbers
                            1: finish
                            2: view correct guesses
                            3: view incorrect guesses
                            4: enter a correct guess
                            5: delete a correct guess
                            6: enter incorrect guess
                            7: delete incorrect guess
                            """);
                    System.out.print("Enter Number for Decision: ");
                    input = validIntInput();
                    if (input >= 1 && input <= 7) {
                        switch(input) {
                            case 1:
                                end = true;
                                break;
                            case 2:
                                getCorrectGuesses();
                                break;
                            case 3:
                                getIncorrectGuesses();
                                break;
                            case 4:
                                System.out.print("Enter the correct guess or quit/q to quit: ");
                                String name4;
                                String attribute4;
                                while (true) {
                                    String guessInput = sc.nextLine().trim();
                                    if (guessInput.replaceAll("\\s", "").equalsIgnoreCase("quit") || guessInput.equalsIgnoreCase("q")) break;
                                    String[] parts4 = guessInput.split(",", 2);
                                    if (parts4.length != 2) {
                                        System.out.print("Invalid input format. Please enter both name and attribute separated by a space or quit/q to quit: ");
                                        continue;
                                    }
                                    name4 = parts4[0];
                                    attribute4 = parts4[1];
                                    if (!repeatGuess(name4, attribute4)) {
                                        addManualGuess(name4, attribute4, 0);
                                        break;
                                    }
                                    else System.out.print("Guess already exits. Please enter guess again: ");
                                }
                                break;

                            case 5:
                                if (noGuesses()) {
                                    System.out.print("Enter the Name & Attribute of the guess separated by a comma or quit/q to quit: ");
                                    String name5;
                                    String attribute5;
                                    while (true) {
                                        String newInput = sc.nextLine().trim();
                                        if (newInput.replaceAll("\\s", "").equalsIgnoreCase("quit") || newInput.equalsIgnoreCase("q")) break;
                                        String[] parts5 = newInput.split(",", 2);
                                        if (parts5.length != 2) {
                                            System.out.print("Invalid input format. Please enter both name and attribute separated by a space or quit/q to quit: ");
                                            continue;
                                        }
                                        name5 = parts5[0];
                                        attribute5 = parts5[1];
                                        if (repeatGuess(name5, attribute5)) {
                                            int guessIndex = getGuessIndex(name5, attribute5, 0);
                                            removeGuess(guessIndex, 0);
                                            break;
                                        }
                                        else System.out.print("Guess not found Please try again: ");
                                    }
                                }
                                else System.out.println("No guesses have been made");
                                break;

                            case 6:
                                System.out.print("Enter the incorrect guess or quit/q to quit: ");
                                String name6;
                                String attribute6;
                                while (true) {
                                    String guessInput = sc.nextLine().trim();
                                    if (guessInput.replaceAll("\\s", "").equalsIgnoreCase("quit") || guessInput.equalsIgnoreCase("q")) break;
                                    String[] parts6 = guessInput.split(",", 2);
                                    if (parts6.length != 2) {
                                        System.out.print("Invalid input format. Please enter both name and attribute separated by a space or quit/q to quit: ");
                                        continue;
                                    }
                                    name6 = parts6[0];
                                    attribute6 = parts6[1];
                                    if (!repeatGuess(name6, attribute6)) {
                                        addManualGuess(name6, attribute6, 1);
                                        break;
                                    }
                                    else System.out.print("Guess already exits. Please enter guess again: ");
                                }
                                break;

                            case 7:
                                if (noGuesses()) {
                                    System.out.print("Enter the Name & Attribute of the guess separated by a comma or quit/q to quit: ");
                                    String name7;
                                    String attribute7;
                                    while (true) {
                                        String newInput = sc.nextLine().trim();
                                        if (newInput.replaceAll("\\s", "").equalsIgnoreCase("quit") || newInput.equalsIgnoreCase("q")) break;
                                        String[] parts7 = newInput.split(",", 2);
                                        if (parts7.length != 2) {
                                            System.out.print("Invalid input format. Please enter both name and attribute separated by a space or quit/q to quit: ");
                                            continue;
                                        }
                                        name7 = parts7[0];
                                        attribute7 = parts7[1];
                                        if (repeatGuess(name7, attribute7)) {
                                            int guessIndex = getGuessIndex(name7, attribute7, 1);
                                            removeGuess(guessIndex, 1);
                                            break;
                                        }
                                        else System.out.print("Guess not found Please try again: ");
                                    }
                                }
                                else System.out.println("No guesses have been made");
                                break;
                        }
                    }
                    if (end) break;
                }
            case 1: break;
        }
    }

    private static void removeGuess(int index, int flag) {
        if (flag == 0) {
            switch(categoryID) {
                case 1:
                    correctGuessesA.remove(index);
                    break;
                case 2:
                    correctGuessesC.remove(index);
                    break;
                case 3:
                    correctGuessesV.remove(index);
                    break;
            }
        }
        else if (flag == 1) {
            switch(categoryID) {
                case 1:
                    incorrectGuessesA.remove(index);
                    break;
                case 2:
                    incorrectGuessesC.remove(index);
                    break;
                case 3:
                    incorrectGuessesV.remove(index);
                    break;
            }
        }
    }

    private static void addManualGuess(String name, String attribute, int flag) {
        if (flag == 0) {
            switch(categoryID){
                case 1:
                    Anime anime = new Anime(name, attribute);
                    correctGuessesA.add(anime);
                    for (int i = 0; i < activeHintsA.size(); i++) {
                        for (Anime currentObjectA : correctGuessesA) {
                            if (currentObjectA.getName().replaceAll("\\s", "").equalsIgnoreCase(anime.getName().replaceAll("\\s", "")) && currentObjectA.getAttribute().replaceAll("\\s", "").equalsIgnoreCase(anime.getAttribute().replaceAll("\\s", ""))) {
                                activeHintsA.remove(currentObjectA);
                                break;
                            }
                        }
                    }
                    break;
                case 2:
                    Character character = new Character(name, attribute);
                    correctGuessesC.add(character);
                    for (int i = 0; i < activeHintsC.size(); i++) {
                        for (Character currentObjectC : correctGuessesC) {
                            if (currentObjectC.getName().replaceAll("\\s", "").equalsIgnoreCase(character.getName().replaceAll("\\s", "")) && currentObjectC.getAttribute().replaceAll("\\s", "").equalsIgnoreCase(character.getAttribute().replaceAll("\\s", ""))) {
                                activeHintsC.remove(currentObjectC);
                                break;
                            }
                        }
                    }
                    break;
                case 3:
                    VideoGame videoGame = new VideoGame(name, attribute);
                    correctGuessesV.add(videoGame);
                    for (int i = 0; i < activeHintsV.size(); i++) {
                        for (VideoGame currentObjectV : correctGuessesV) {
                            if (currentObjectV.getName().replaceAll("\\s", "").equalsIgnoreCase(videoGame.getName().replaceAll("\\s", "")) && currentObjectV.getAttribute().replaceAll("\\s", "").equalsIgnoreCase(videoGame.getAttribute().replaceAll("\\s", ""))) {
                                activeHintsV.remove(currentObjectV);
                                break;
                            }
                        }
                    }
                    break;
            }
        }
        else if (flag == 1) {
            switch(categoryID){
                case 1:
                    Anime anime = new Anime(name, attribute);
                    incorrectGuessesA.add(anime);
                    break;
                case 2:
                    Character character = new Character(name, attribute);
                    incorrectGuessesC.add(character);
                    break;
                case 3:
                    VideoGame videoGame = new VideoGame(name, attribute);
                    incorrectGuessesV.add(videoGame);
                    break;
            }
        }
    }

    private static boolean noGuesses() {
        return (correctGuessesA != null && !correctGuessesA.isEmpty()) ||
                (correctGuessesC != null && !correctGuessesC.isEmpty()) ||
                (correctGuessesV != null && !correctGuessesV.isEmpty()) ||
                (incorrectGuessesA != null && !incorrectGuessesA.isEmpty()) ||
                (incorrectGuessesC != null && !incorrectGuessesC.isEmpty()) ||
                (incorrectGuessesV != null && !incorrectGuessesV.isEmpty());

    }

    private static int getGuessIndex(String name, String attribute, int flag) {
        int guessIndex = -1;
        if (flag == 0) {
            switch (categoryID){
                case 1:
                    for (int i = 0; i < correctGuessesA.size(); i++) {
                        if (name.replaceAll("\\s", "").equalsIgnoreCase(correctGuessesA.get(i).getName().replaceAll("\\s", "")) && attribute.replaceAll("\\s", "").equalsIgnoreCase(correctGuessesA.get(i).getAttribute().replaceAll("\\s", ""))) {
                            guessIndex = i;
                            break;
                        }
                    }
                    break;
                case 2:
                    for (int i = 0; i < correctGuessesC.size(); i++) {
                        if (name.replaceAll("\\s", "").equalsIgnoreCase(correctGuessesC.get(i).getName().replaceAll("\\s", "")) && attribute.replaceAll("\\s", "").equalsIgnoreCase(correctGuessesC.get(i).getAttribute().replaceAll("\\s", ""))) {
                            guessIndex = i;
                            break;
                        }
                    }
                    break;
                case 3:
                    for (int i = 0; i < correctGuessesV.size(); i++) {
                        if (name.replaceAll("\\s", "").equalsIgnoreCase(correctGuessesV.get(i).getName().replaceAll("\\s", "")) && attribute.replaceAll("\\s", "").equalsIgnoreCase(correctGuessesV.get(i).getAttribute().replaceAll("\\s", ""))) {
                            guessIndex = i;
                            break;
                        }
                    }
                    break;
            }
        }

        else if (flag == 1) {
            switch (categoryID){
                case 1:
                    for (int i = 0; i < incorrectGuessesA.size(); i++) {
                        if (name.replaceAll("\\s", "").equalsIgnoreCase(incorrectGuessesA.get(i).getName().replaceAll("\\s", "")) && attribute.replaceAll("\\s", "").equalsIgnoreCase(incorrectGuessesA.get(i).getAttribute().replaceAll("\\s", ""))) {
                            guessIndex = i;
                            break;
                        }
                    }
                    break;
                case 2:
                    for (int i = 0; i < incorrectGuessesC.size(); i++) {
                        if (name.replaceAll("\\s", "").equalsIgnoreCase(incorrectGuessesC.get(i).getName().replaceAll("\\s", "")) && attribute.replaceAll("\\s", "").equalsIgnoreCase(incorrectGuessesC.get(i).getAttribute().replaceAll("\\s", ""))) {
                            guessIndex = i;
                            break;
                        }
                    }
                    break;
                case 3:
                    for (int i = 0; i < incorrectGuessesV.size(); i++) {
                        if (name.replaceAll("\\s", "").equalsIgnoreCase(incorrectGuessesV.get(i).getName().replaceAll("\\s", "")) && attribute.replaceAll("\\s", "").equalsIgnoreCase(incorrectGuessesV.get(i).getAttribute().replaceAll("\\s", ""))) {
                            guessIndex = i;
                            break;
                        }
                    }
                    break;
            }
        }

        return guessIndex;
    }

    private static void getCorrectGuesses() {
        switch(categoryID) {
            case 1:
                if (correctGuessesA.isEmpty()) System.out.println(ANSI_YELLOW +"\nNo correct guesses" + ANSI_RESET);
                else {
                    for (Anime anime: correctGuessesA) System.out.println(ANSI_GREEN + anime.toString() + ANSI_RESET);
                }
                break;
            case 2:
                if (correctGuessesC.isEmpty()) System.out.println(ANSI_YELLOW + "\nNo correct guesses" + ANSI_RESET);
                else {
                    for (Character character: correctGuessesC) System.out.println(ANSI_GREEN + character.toString() + ANSI_RESET);
                }
                break;
            case 3:
                if (correctGuessesV.isEmpty()) System.out.println(ANSI_YELLOW + "\nNo correct guesses" + ANSI_RESET);
                else {
                    for (VideoGame videoGame: correctGuessesV) System.out.println(ANSI_GREEN + videoGame.toString() + ANSI_RESET);
                }
                break;
        }
    }

    private static void getIncorrectGuesses() {
        switch(categoryID) {
            case 1:
                if (incorrectGuessesA.isEmpty()) System.out.println(ANSI_YELLOW +"\nNo incorrect guesses" + ANSI_RESET);
                else {
                    for (Anime anime: incorrectGuessesA) System.out.println(ANSI_RED + anime.toString() + ANSI_RESET);
                }
                break;
            case 2:
                if (incorrectGuessesC.isEmpty()) System.out.println(ANSI_YELLOW + "\nNo incorrect guesses" + ANSI_RESET);
                else {
                    for (Character character: incorrectGuessesC) System.out.println(ANSI_RED + character.toString() + ANSI_RESET);
                }
                break;
            case 3:
                if (incorrectGuessesV.isEmpty()) System.out.println(ANSI_YELLOW + "\nNo incorrect guesses" + ANSI_RESET);
                else {
                    for (VideoGame videoGame: incorrectGuessesV) System.out.println(ANSI_RED + videoGame.toString() + ANSI_RESET);
                }
                break;
        }
    }

    private static void getActiveHints() {
        switch(categoryID) {
            case 1:
                if (activeHintsA.isEmpty()) System.out.println(ANSI_YELLOW + "\nNo active hints" + ANSI_RESET);
                else {
                    for (Anime anime: activeHintsA) System.out.println(ANSI_YELLOW + anime.getAttribute() + ANSI_RESET);
                }
                break;
            case 2:
                if (activeHintsC.isEmpty()) System.out.println(ANSI_YELLOW + "\nNo active hints" + ANSI_RESET);
                else {
                    for (Character character: activeHintsC) System.out.println(ANSI_YELLOW + character.getAttribute() + ANSI_RESET);
                }
                break;
            case 3:
                if (activeHintsV.isEmpty()) System.out.println(ANSI_YELLOW + "\nNo active hints" + ANSI_RESET);
                else {
                    for (VideoGame videoGame: activeHintsV) System.out.println(ANSI_YELLOW + videoGame.getAttribute() + ANSI_RESET);
                }
                break;
        }
    }

    private static void useHint(Player player) {
        if (player.getHints() > 0) {
            switch(categoryID) {
                case 1:
                    System.out.println(ANSI_YELLOW +"\nHint: " + answerListA.getFirst().getAttribute() + ANSI_RESET);
                    activeHintsA.add(answerListA.getFirst());
                    break;
                case 2:
                    System.out.println(ANSI_YELLOW + "\nHint: " + answerListC.getFirst().getAttribute() + ANSI_RESET);
                    activeHintsC.add(answerListC.getFirst());
                    break;
                case 3:
                    System.out.println(ANSI_YELLOW +"\nHint: " + answerListV.getFirst().getAttribute() + ANSI_RESET);
                    activeHintsV.add(activeHintsV.getFirst());
                    break;
            }
            player.setHints(player.getHints() - 1);
        }
        else System.out.println(ANSI_YELLOW +"\nNo Hints remaining" + ANSI_RESET);
    }

    private static boolean repeatGuess(String name, String attribute) {
        boolean repeat = false;
        switch(categoryID) {
            case 1:
                for (Anime anime : correctGuessesA) {
                    if (name.replaceAll("\\s", "").equalsIgnoreCase(anime.getName().replaceAll("\\s", "")) && attribute.replaceAll("\\s", "").equalsIgnoreCase(anime.getAttribute().replaceAll("\\s", ""))) {
                        repeat = true;
                        break;
                    }
                }
                if (!repeat) {
                    for (Anime anime : incorrectGuessesA) {
                        if (name.replaceAll("\\s", "").equalsIgnoreCase(anime.getName().replaceAll("\\s", "")) && attribute.replaceAll("\\s", "").equalsIgnoreCase(anime.getAttribute().replaceAll("\\s", ""))) {
                            repeat = true;
                            break;
                        }
                    }
                }
                break;
            case 2:
                for (Character character : correctGuessesC) {
                    if (name.replaceAll("\\s", "").equalsIgnoreCase(character.getName().replaceAll("\\s", "")) && attribute.replaceAll("\\s", "").equalsIgnoreCase(character.getAttribute().replaceAll("\\s", ""))) {
                        repeat = true;
                        break;
                    }
                }
                if (!repeat) {
                    for (Character character : incorrectGuessesC) {
                        if (name.replaceAll("\\s", "").equalsIgnoreCase(character.getName().replaceAll("\\s", "")) && attribute.replaceAll("\\s", "").equalsIgnoreCase(character.getAttribute().replaceAll("\\s", ""))) {
                            repeat = true;
                            break;
                        }
                    }
                }
                break;
            case 3:
                for (VideoGame videoGame : correctGuessesV) {
                    if (name.replaceAll("\\s", "").equalsIgnoreCase(videoGame.getName().replaceAll("\\s", "")) && attribute.replaceAll("\\s", "").equalsIgnoreCase(videoGame.getAttribute().replaceAll("\\s", ""))) {
                        repeat = true;
                        break;
                    }
                }
                if (!repeat) {
                    for (VideoGame videoGame : incorrectGuessesV) {
                        if (name.replaceAll("\\s", "").equalsIgnoreCase(videoGame.getName().replaceAll("\\s", "")) && attribute.replaceAll("\\s", "").equalsIgnoreCase(videoGame.getAttribute().replaceAll("\\s", ""))) {
                            repeat = true;
                            break;
                        }
                    }
                }
                break;
        }
        return repeat;
    }

    private static boolean checkGuess(String name, String attribute) {
        boolean correct = false;
        switch(categoryID) {
            case 1:
                Anime newObjectA = new Anime(name, attribute);
                for (Anime anime : answerListA) {
                    if (newObjectA.getName().replaceAll("\\s", "").equalsIgnoreCase(anime.getName().replaceAll("\\s", "")) && newObjectA.getAttribute().replaceAll("\\s", "").equalsIgnoreCase(anime.getAttribute().replaceAll("\\s", ""))) {
                        correctGuessesA.add(newObjectA);
                        correct = true;
                    }
                }
                if (correct) {
                    for (int i = 0; i < activeHintsA.size(); i++) {
                        Anime currentObjectA = activeHintsA.get(i);
                        for (Anime anime : correctGuessesA) {
                            if (currentObjectA.getName().replaceAll("\\s", "").equalsIgnoreCase(anime.getName().replaceAll("\\s", "")) && currentObjectA.getAttribute().replaceAll("\\s", "").equalsIgnoreCase(anime.getAttribute().replaceAll("\\s", ""))) {
                                activeHintsA.remove(currentObjectA);
                                break;
                            }
                        }
                    }
                }
                else incorrectGuessesA.add(newObjectA);
                break;
            case 2:
                Character newObjectC = new Character(name, attribute);
                for (Character character : answerListC) {
                    if (newObjectC.getName().replaceAll("\\s", "").equalsIgnoreCase(character.getName().replaceAll("\\s", "")) && newObjectC.getAttribute().replaceAll("\\s", "").equalsIgnoreCase(character.getAttribute().replaceAll("\\s", ""))) {
                        correctGuessesC.add(newObjectC);
                        correct = true;
                    }
                }
                if (correct) {
                    for (int i = 0; i < activeHintsC.size(); i++) {
                        Character currentObjectC = activeHintsC.get(i);
                        for (Character character : correctGuessesC) {
                            if (currentObjectC.getName().replaceAll("\\s", "").equalsIgnoreCase(character.getName().replaceAll("\\s", "")) && currentObjectC.getAttribute().replaceAll("\\s", "").equalsIgnoreCase(character.getAttribute().replaceAll("\\s", ""))) {
                                activeHintsC.remove(currentObjectC);
                                break;
                            }
                        }
                    }
                }
                else incorrectGuessesC.add(newObjectC);
                break;
            case 3:
                VideoGame newObjectV = new VideoGame(name, attribute);
                for (VideoGame videoGame : answerListV) {
                    if (newObjectV.getName().replaceAll("\\s", "").equalsIgnoreCase(videoGame.getName().replaceAll("\\s", "")) && newObjectV.getAttribute().replaceAll("\\s", "").equalsIgnoreCase(videoGame.getAttribute().replaceAll("\\s", ""))) {
                        correctGuessesV.add(newObjectV);
                        correct = true;
                    }
                }
                if (correct) {
                    for (int i = 0; i < activeHintsV.size(); i++) {
                        VideoGame currentObjectV = activeHintsV.get(i);
                        for (VideoGame videoGame : correctGuessesV) {
                            if (currentObjectV.getName().replaceAll("\\s", "").equalsIgnoreCase(videoGame.getName().replaceAll("\\s", "")) && currentObjectV.getAttribute().replaceAll("\\s", "").equalsIgnoreCase(videoGame.getAttribute().replaceAll("\\s", ""))) {
                                activeHintsV.remove(currentObjectV);
                                break;
                            }
                        }
                    }
                }
                else incorrectGuessesV.add(newObjectV);
                break;
        }
        return correct;
    }

    //Creation Functions
    private static int createAnswerList(List<String> answers, String csvFile, int numOfAnswers, int typeFlag) {
        if (typeFlag == 0) {

            try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
                String line;

                while ((line = br.readLine()) != null) {
                    String modifiedLine = line.replaceAll("[^a-zA-Z0-9,.:?!();'\"-]", " ").trim();
                    String[] values = modifiedLine.split(",");
                    if (values.length != (numOfAnswers*2)) {
                        System.out.println("Incorrect format or number of answers");
                        return 0;
                    }

                    answers.addAll(Arrays.asList(values));
                }
            } catch (IOException e) {
                System.out.println("Could not find file.");
                return 0;

            }
        }

        if (typeFlag == 1) {
            for (int i = 0; i < numOfAnswers; i++) {
                System.out.print("Enter the name of answer " + (i + 1) + ": ");
                String name = sc.nextLine().trim();
                answers.add(name);
                System.out.print("Enter the attribute of answer " + (i + 1) + ": ");
                String attribute = sc.nextLine().trim();
                answers.add(attribute);
            }
        }
        return 1;
    }

    private static void createAnswerObjects(List<String> answers, int numOfAnswers) {
        String item;
        String attribute;
        switch (categoryID) {
            case 1:
                answerListA = new ArrayList<>();
                for (int i = 0, j = 0; i < numOfAnswers && j < answers.size(); i++, j += 2) {
                    item = answers.get(j);
                    attribute = answers.get(j + 1);
                    Anime anime = new Anime(item, attribute);
                    answerListA.add(anime);
                }
                break;
            case 2:
                answerListC = new ArrayList<>();
                for (int i = 0, j = 0; i < numOfAnswers && j < answers.size(); i++, j += 2) {
                    item = answers.get(j);
                    attribute = answers.get(j + 1);
                    Character character = new Character(item, attribute);
                    answerListC.add(character);
                }
                break;
            case 3:
                answerListV = new ArrayList<>();
                for (int i = 0, j = 0; i < numOfAnswers && j < answers.size(); i++, j += 2) {
                    item = answers.get(j);
                    attribute = answers.get(j + 1);
                    VideoGame videoGame = new VideoGame(item, attribute);
                    answerListV.add(videoGame);
                }
                break;
            default:
                break;
        }
    }

    private static void createPlayers(int participants) {
        ArrayList<String> namesAlreadyUsed = new ArrayList<>();
        ArrayList<Integer> placementsAlreadyUsed = new ArrayList<>();
        ArrayList<Integer> positionsAlreadyUsed = new ArrayList<>();
        int maxHints = Integer.compare(participants, 3);

        for (int i = 0; i < participants; i++) {
            String name = validPlayerName(namesAlreadyUsed, i);
            namesAlreadyUsed.add(name);
            int placement = validPlacement(placementsAlreadyUsed, participants);
            placementsAlreadyUsed.add(placement);
            int position = validPosition(positionsAlreadyUsed, participants);
            positionsAlreadyUsed.add(position);
            System.out.print("Enter the amount of lives player " + (i + 1) + " starts with: ");
            int lives = validIntInput();
            Player currentPlayer = new Player(name, placement, position, lives);
            players.add(currentPlayer);

            switch (maxHints) {
                case 0:
                    if (players.get(i).getPlacement() == 1) players.get(i).setHints(1);
                    break;
                case 1:
                    switch (players.get(i).getPlacement()) {
                        case 1:
                            players.get(i).setHints(3);
                            break;
                        case 2:
                            players.get(i).setHints(2);
                            break;
                        case 3:
                            players.get(i).setHints(1);
                            break;
                        default:
                            break;
                    }
                default:
                    break;
            }
        }
    }

    // Validation Functions
    private static String validInput(String[] validAnswers) {
        String input;
        while (true) {
            input = sc.nextLine().trim();
            if (input.equalsIgnoreCase("quit")) return "quit";
            for (String validAnswer : validAnswers) {
                if (input.equalsIgnoreCase(validAnswer)) {
                    return input;
                }
            }
            System.out.print("Invalid input! Please try again: ");
        }
    }

    private static int validIntInput() {
        while (true) {
            String input = sc.nextLine().trim();
            if (input.equalsIgnoreCase("quit") || input.equalsIgnoreCase("q")) return -1;
            try {
                int intInput = Integer.parseInt(input);
                if (intInput > 0) return intInput;
            } catch (NumberFormatException ignored) {
            }
            System.out.print("Invalid input! Please enter a positive integer or quit/q to quit: ");
        }
    }

    private static String validPlayerName(ArrayList<String> names, int currentPlayer) {
        String name;
        System.out.print("Enter the name of player " + (currentPlayer + 1) + ": ");
        while (true) {
            name = sc.nextLine().trim();
            if (!names.contains(name)) {
                break;
            }
            else {
                System.out.print("Name has already been used. Please enter a different name: ");
            }
        }
        return name;
    }

    private static int validPlacement(ArrayList<Integer> placements, int numOfPlayers) {
        int placement;
        System.out.print("Enter the placement (placement at the end of the jeopardy) of the player: ");
        while (true) {
            placement = validIntInput();
            if (placement == -1) System.exit(1);
            if (placement > 0 && placement <= numOfPlayers) {
                if (!placements.contains(placement)) {
                    break;
                }
                else {
                    System.out.print("Placement has already been used. Please enter a different placement: ");
                }
            }
            else {
                System.out.print("Invalid placement (Outside of Range). Please enter a valid placement: ");
            }
        }
        return placement;
    }

    private static int validPosition(ArrayList<Integer> positions, int numOfPlayers) {
        int position;
        System.out.print("Enter the position (turn order of the final Jeopardy) of the player: ");
        while (true) {
            position = validIntInput();
            if (position == -1) System.exit(1);
            if (position > 0 && position <= numOfPlayers) {
                if (!positions.contains(position)) {
                    break;
                }
                else {
                    System.out.print("Position has already been used. Please enter a different position: ");
                }
            }
            else {
                System.out.print("Invalid position (Outside of Range). Please enter a valid position: ");
            }
        }
        return position;
    }
}