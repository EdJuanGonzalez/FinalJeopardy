public class VideoGame {
    private String name;
    private String releaseYear;
    private int rank;

    public VideoGame(String name, String releaseYear) {
        this.name = name;
        this.releaseYear = releaseYear;
        this.rank = 0;
    }

    public VideoGame(String name, String releaseYear, int rank) {
        this.name = name;
        this.releaseYear = releaseYear;
        this.rank = rank;
    }

    //setters

    public void setName (String name) {
        this.name = name;
    }

    public void setReleaseYear (String releaseYear) {
        this.releaseYear = releaseYear;
    }

    public void setRank (int rank) {
        this.rank = rank;
    }

    //getters

    public String getName() {
        return this.name;
    }

    public String getReleaseYear() {
        return this.releaseYear;
    }

    public int getRank() {
        return this.rank;
    }

    //to String

    public String toString() {
        return "Name: " + this.name + "\n" + "ReleaseYear: " + this.releaseYear + "\n" + "Rank: " + this.rank;
    }
}
