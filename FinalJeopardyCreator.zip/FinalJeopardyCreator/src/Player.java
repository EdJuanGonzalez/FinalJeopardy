public class Player {
    private String name; //the name of the player
    private int placement; //the placement of the player in the jeopardy
    private int position; //the position of the player in the turn order
    private int lives; // the number of lives the player has;
    private int hints; // the number of hints a player has

    //constructor
    public Player(String name, int placement, int position, int lives) {
        this.name = name;
        this.placement = placement;
        this.position = position;
        this.lives = lives;
        this.hints = 0;
    }

    //setters

    public void setName(String name) {
        this.name = name;
    }

    public void setPlacement(int placement) {
        this.placement = placement;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public void setLives(int lives) {
        this.lives = lives;
    }

    public void setHints(int hints) {
        this.hints = hints;
    }

    //getters

    public String getName() {
        return this.name;
    }

    public int getPlacement() {
        return this.placement;
    }

    public int getPosition() {
        return this.position;
    }

    public int getLives() {
        return this.lives;
    }

    public int getHints() {
        return this.hints;
    }

    //toString method

    public String toString() {
        String p = "Going ";
        switch(this.position) {
            case 1:
                p = "st";

            case 2:
                p = "nd";

            case 3:
                p = "rd";

            default:
                p = "th";
        }//end switch(this.position)
        return "Name: " + this.name + " Placement: "+ this.placement + " Going: " + this.position + p + " Lives: " + this.lives + " Hints: " + this.hints;
    }
}
