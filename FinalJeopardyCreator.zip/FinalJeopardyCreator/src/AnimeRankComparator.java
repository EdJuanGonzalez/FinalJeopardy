import java.util.Comparator;
class AnimeRankComparator implements Comparator<Anime> {
    @Override
    public int compare(Anime anime1, Anime anime2) {
        // Compare characters based on their rank field
        return Integer.compare(anime1.getRank(), anime2.getRank());
    }
}