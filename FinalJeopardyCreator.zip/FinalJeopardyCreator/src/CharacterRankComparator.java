import java.util.Comparator;
class CharacterRankComparator implements Comparator<Character> {
    @Override
    public int compare(Character character1, Character character2) {
        // Compare characters based on their rank field
        return Integer.compare(character1.getRank(), character2.getRank());
    }
}