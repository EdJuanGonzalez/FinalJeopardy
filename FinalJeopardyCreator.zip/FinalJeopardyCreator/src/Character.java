public class Character {
    private String name; //the name of the character
    private String series; //the name of the series where the character is from
    private int rank; //the rank of the character based on host's ranking

    //Constructor without a rank
    public Character(String name, String series) {
        this.name = name;
        this.series = series;
        this.rank = 0;
    }

    //Constructor with rank
    public Character(String name, String series, int rank) {
        this.name = name;
        this.series = series;
        this.rank = rank;
    }

    //setters

    public void setName(String name) {
        this.name = name;
    }

    public void setSeries(String series) {
        this.series =series;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    //getters

    public String getName() {
        return this.name;
    }

    public String getSeries() {
        return this.series;
    }

    public int getRank() {
        return this.rank;
    }

    //toString method

    public String toString() {
        return "Name: " + this.name + "\n" + "Series: " + this.series + "\n" + "Rank: " + this.rank;
    }
}
