public class Character {
    private String name; //the name of the character
    private String attribute; //the name of the series where the character is from

    public Character(String name, String series) {
        this.name = name;
        this.attribute = series;
    }

    //setters

    public void setName(String name) {
        this.name = name;
    }

    public void setAttribute(String series) {
        this.attribute =series;
    }

    //getters

    public String getName() {
        return this.name;
    }

    public String getAttribute() {
        return this.attribute;
    }

    //toString method

    public String toString() {
        return "Name: " + this.name + " Series: " + this.attribute;
    }
}
