import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import static java.lang.System.exit;


public class Main {
    private static final Scanner sc = new Scanner(System.in); //Scanner
    //possible lists
    static ArrayList<Anime> animeList;
    static ArrayList<Character> characterList;
    static ArrayList<VideoGame> videoGameList;
    private static int categoryID = 0;
    public static void main(String[] args) {

        final String[] categories = {"Anime", "a", "Character", "c", "Video Game", "v"}; // Possible Categories
        final String hostKey; //The host key to make changes

        System.out.print("Please Enter a hostKey: ");
        hostKey = sc.nextLine();

        System.out.print("Jeopardy category: Anime/a, Character/c, Video Game/v: ");

        String categoryType = validInput(categories);

        if (categoryType.equalsIgnoreCase("quit")) exit(1);
        if (categoryType.equalsIgnoreCase("Anime") || categoryType.equalsIgnoreCase("A")) {
            categoryID = 1;
        }
        else if (categoryType.equalsIgnoreCase("Character") || categoryType.equalsIgnoreCase("c")) {
            categoryID = 2;
        }
        else if (categoryType.equalsIgnoreCase("Video Game") || categoryType.equalsIgnoreCase("v")) {
            categoryID = 3;
        }

        System.out.print("""
                Do you have a csv file that contains the answers in one of the following formats
                Anime: Name, Release Year
                Character: Full Name, Series
                Video Game: Name, Release Year
                """);

        System.out.print("Enter yes/y or no/n: ");

        String[] yesOrNo = {"yes", "y", "no", "n"};

        String yn = validInput(yesOrNo);

        if (categoryType.equalsIgnoreCase("quit")) exit(1);

        System.out.print("How many unique answers do you have: ");

        int numOfAnswers = validIntInput();

        if (numOfAnswers == -1) exit(1);

        List<String> answers = new ArrayList<>();
        if (yn.equalsIgnoreCase("yes") || yn.equalsIgnoreCase("y")) {
            String path = "answerfile/";
            System.out.println("Please make sure that the file is in the answerFile Folder");
            System.out.print("Please enter the name of the file: ");
            String fileName = sc.nextLine();
            path = path.concat(fileName);
            int success = createAnswerList(answers, path, numOfAnswers, 0);

            if (success == 0) exit(1);
        }
        else {
            int success = createAnswerList(answers, null, numOfAnswers, 1);
            if (success == 0) exit(1);
        }

        if (categoryID == 1) {
            animeList = new ArrayList<>();
            createAnswerObjects(answers, numOfAnswers);
        }
        else if (categoryID == 2) {
            characterList = new ArrayList<>();
            createAnswerObjects(answers, numOfAnswers);
        }
        else if (categoryID == 3) {
            videoGameList = new ArrayList<>();
            createAnswerObjects(answers, numOfAnswers);
        }
    }

    public static String validInput(String[] validAnswers) {
        boolean unsuccessful = true;
        String input = "";
        while (unsuccessful) {
            input = sc.nextLine();
            if (input.equalsIgnoreCase("q") || input.equalsIgnoreCase("quit")) return "quit";
            for (String validAnswer : validAnswers) {
                if (input.equalsIgnoreCase(validAnswer)) {
                    unsuccessful = false;
                    break;
                }
            }
            if (unsuccessful) System.out.print("Invalid Answer: Please type Anime/a, Character/c, or VideoGame/v\nIf you " +
                    "want to quit please enter quit/q: ");
        }
        return input;
    }

    public static int validIntInput() {
        boolean unsuccessful = true;
        int intInput = 0;
        String input;

        while (unsuccessful) {
            input = sc.nextLine();
            if (input.equalsIgnoreCase("q") || input.equalsIgnoreCase("quit")) return -1;
            try {
                intInput = Integer.parseInt(input);
                if (intInput >= 0) unsuccessful = false;
                else System.out.print("Please enter a positive integer or quit/q to quit: ");
            } catch (NumberFormatException e) {
                System.out.print("Invalid Input. Please enter a positive number or quit/q to quit: ");
            }
        }
        return intInput;
    }

    public static int createAnswerList(List<String> answers, String csvFile, int numOfAnswers, int typeFlag) {
        if (typeFlag == 0) {
            try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
                String line;

                while ((line = br.readLine()) != null) {
                    String modifiedLine = line.replaceAll("[^a-zA-Z0-9,.:?!();'\"-]", " ");
                    String[] values = modifiedLine.split(",");

                    answers.addAll(Arrays.asList(values));
                }
            } catch (IOException e) {
                System.out.println("Could not find file.");
                return 0;

            } catch(Exception e) {
                System.out.println("Incorrect format or number of answers");
                return 0;
            }
        }

        if (typeFlag == 1) {
            for (int i = 0; i < numOfAnswers; i++) {
                System.out.print("Enter the name of answer " + (i+1) + ": ");
                String name = sc.nextLine();
                answers.add(name);
                System.out.print("Enter the attribute of answer " + (i+1) + ": ");
                String attribute = sc.nextLine();
                answers.add(attribute);
            }
        }
        return 1;
    }

    public static void createAnswerObjects(List<String> answers, int numOfAnswers) {
        String item;
        String attribute;
        if (categoryID == 1) {
            for (int i = 0, j = 0; i < numOfAnswers && j < answers.size(); i++, j+=2) {
                item = answers.get(j);
                attribute = answers.get(j+1);
                Anime anime = new Anime(item, attribute);
                animeList.add(anime);
            }
        }
        else if (categoryID == 2) {
            for (int i = 0, j = 0; i < numOfAnswers && j < answers.size(); i++, j+=2) {
                item = answers.get(j);
                attribute = answers.get(j+1);
                Character character = new Character(item, attribute);
                characterList.add(character);
            }
        }

        if (categoryID == 3) {
            for (int i = 0, j = 0; i < numOfAnswers && j < answers.size(); i++, j+=2) {
                item = answers.get(j);
                attribute = answers.get(j+1);
                VideoGame videoGame = new VideoGame(item, attribute);
                videoGameList.add(videoGame);
            }
        }
    }
}