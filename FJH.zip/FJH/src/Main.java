import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static List<String> answers;
    private static ArrayList<Anime> animeList;
    private static ArrayList<Character> characterList;
    private static ArrayList<VideoGame> videoGameList;
    private static int categoryID = 0;
    private static Player[] players;

    public static void main(String[] args) {
        setupGame();
        startFinalJeopardy();
    }

    public static void setupGame() {
        setupAnswers();
        setupPlayers();
    }

    public static void setupAnswers() {
        final String[] categories = {"Anime", "a", "Character", "c", "Video Game", "v"};
        System.out.print("Jeopardy category: Anime/a, Character/c, Video Game/v: ");
        String categoryType = validInput(categories);

        if (categoryType.equalsIgnoreCase("quit")) System.exit(1);
        switch (categoryType.toLowerCase()) {
            case "anime":
            case "a":
                categoryID = 1;
                break;
            case "character":
            case "c":
                categoryID = 2;
                break;
            case "video game":
            case "v":
                categoryID = 3;
                break;
            default:
                System.out.println("Invalid category!");
                System.exit(1);
        }

        System.out.println("Enter answers for the category.");
        System.out.print("Do you have a CSV file containing answers (yes/y or no/n): ");
        String yn = validInput(new String[]{"yes", "y", "no", "n"});

        if (yn.equalsIgnoreCase("quit")) System.exit(1);

        System.out.print("How many unique answers do you have: ");
        int numOfAnswers = validIntInput();
        if (numOfAnswers == -1) System.exit(1);

        answers = new ArrayList<>();
        if (yn.equalsIgnoreCase("yes") || yn.equalsIgnoreCase("y")) {
            String path = "answerfile/";
            System.out.println("Please make sure that the file is in the answerFile Folder");
            System.out.print("Please enter the name of the file: ");
            String fileName = sc.nextLine();
            path = path.concat(fileName);
            int success = createAnswerList(answers, path, numOfAnswers, 0);
            if (success == 0) System.exit(1);
        }
        else {
            int success = createAnswerList(answers, null, numOfAnswers, 1);
            if (success == 0) System.exit(1);
        }

        switch (categoryID) {
            case 1:
                animeList = new ArrayList<>();
                createAnswerObjects(answers, numOfAnswers);
                break;
            case 2:
                characterList = new ArrayList<>();
                createAnswerObjects(answers, numOfAnswers);
                break;
            case 3:
                videoGameList = new ArrayList<>();
                createAnswerObjects(answers, numOfAnswers);
                break;
            default:
                System.out.println("Invalid category!");
                System.exit(1);
        }
    }

    public static void setupPlayers() {
        System.out.print("How many players are in the final jeopardy: ");
        int participants = validIntInput();
        if (participants < 2) {
            System.out.println("Invalid number of players!");
            System.out.print("Please enter a number greater than 1");
            participants = validIntInput();
        }
        players = new Player[participants];
        createPlayers(participants);
    }

    public static void startFinalJeopardy() {
        int playersLeft = players.length;
    }

    private static String validInput(String[] validAnswers) {
        String input;
        while (true) {
            input = sc.nextLine();
            if (input.equalsIgnoreCase("quit")) return "quit";
            for (String validAnswer : validAnswers) {
                if (input.equalsIgnoreCase(validAnswer)) {
                    return input;
                }
            }
            System.out.print("Invalid input! Please try again: ");
        }
    }

    private static int validIntInput() {
        while (true) {
            String input = sc.nextLine();
            if (input.equalsIgnoreCase("quit") || input.equalsIgnoreCase("q")) return -1;
            try {
                int intInput = Integer.parseInt(input);
                if (intInput > 0) return intInput;
            } catch (NumberFormatException ignored) {
            }
            System.out.print("Invalid input! Please enter a positive integer or quit/q to quit: ");
        }
    }

    private static int createAnswerList(List<String> answers, String csvFile, int numOfAnswers, int typeFlag) {
        if (typeFlag == 0) {
            try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
                String line;

                while ((line = br.readLine()) != null) {
                    String modifiedLine = line.replaceAll("[^a-zA-Z0-9,.:?!();'\"-]", " ");
                    String[] values = modifiedLine.split(",");

                    answers.addAll(Arrays.asList(values));
                }
            } catch (IOException e) {
                System.out.println("Could not find file.");
                return 0;

            } catch (Exception e) {
                System.out.println("Incorrect format or number of answers");
                return 0;
            }
        }

        if (typeFlag == 1) {
            for (int i = 0; i < numOfAnswers; i++) {
                System.out.print("Enter the name of answer " + (i + 1) + ": ");
                String name = sc.nextLine();
                answers.add(name);
                System.out.print("Enter the attribute of answer " + (i + 1) + ": ");
                String attribute = sc.nextLine();
                answers.add(attribute);
            }
        }
        return 1;
    }

    private static void createAnswerObjects(List<String> answers, int numOfAnswers) {
        String item;
        String attribute;
        switch (categoryID) {
            case 1:
                animeList = new ArrayList<>();
                for (int i = 0, j = 0; i < numOfAnswers && j < answers.size(); i++, j += 2) {
                    item = answers.get(j);
                    attribute = answers.get(j + 1);
                    Anime anime = new Anime(item, attribute);
                    animeList.add(anime);
                }
                break;
            case 2:
                characterList = new ArrayList<>();
                for (int i = 0, j = 0; i < numOfAnswers && j < answers.size(); i++, j += 2) {
                    item = answers.get(j);
                    attribute = answers.get(j + 1);
                    Character character = new Character(item, attribute);
                    characterList.add(character);
                }
                break;
            case 3:
                videoGameList = new ArrayList<>();
                for (int i = 0, j = 0; i < numOfAnswers && j < answers.size(); i++, j += 2) {
                    item = answers.get(j);
                    attribute = answers.get(j + 1);
                    VideoGame videoGame = new VideoGame(item, attribute);
                    videoGameList.add(videoGame);
                }
                break;
            default:
                break;
        }
    }

    private static void createPlayers(int participants) {
        ArrayList<String> namesAlreadyUsed = new ArrayList<>();
        ArrayList<Integer> placementsAlreadyUsed = new ArrayList<>();
        ArrayList<Integer> positionsAlreadyUsed = new ArrayList<>();
        int maxHints = Integer.compare(participants, 3);

        for (int i = 0; i < participants; i++) {
            String name = validPlayerName(namesAlreadyUsed, i);
            namesAlreadyUsed.add(name);
            int placement = validPlacement(placementsAlreadyUsed, players.length);
            placementsAlreadyUsed.add(placement);
            int position = validPosition(positionsAlreadyUsed, players.length);
            positionsAlreadyUsed.add(position);
            System.out.print("Enter the amount of lives player " + (i + 1) + " starts with: ");
            int lives = validIntInput();
            players[i] = new Player(name, placement, position, lives);

            switch (maxHints) {
                case 0:
                    if (players[i].getPlacement() == 1) players[i].setHints(1);
                    break;
                case 1:
                    switch (players[i].getPlacement()) {
                        case 1:
                            players[i].setHints(3);
                            break;
                        case 2:
                            players[i].setHints(2);
                            break;
                        case 3:
                            players[i].setHints(1);
                            break;
                        default:
                            break;
                    }
                default:
                    break;
            }
        }
    }

    private static String validPlayerName(ArrayList<String> names, int currentPlayer) {
        String name;
        System.out.print("Enter the name of player " + (currentPlayer + 1) + ": ");
        while (true) {
            name = sc.nextLine();
            if (!names.contains(name)) {
                break;
            }
            else {
                System.out.print("Name has already been used. Please enter a different name: ");
            }
        }
        return name;
    }

    private static int validPlacement(ArrayList<Integer> placements, int numOfPlayers) {
        int placement;
        System.out.print("Enter the placement (placement at the end of the jeopardy) of the player: ");
        while (true) {
            placement = validIntInput();
            if (placement == -1) System.exit(1);
            if (placement > 0 && placement <= numOfPlayers) {
                if (!placements.contains(placement)) {
                    break;
                }
                else {
                    System.out.print("Placement has already been used. Please enter a different placement: ");
                }
            }
            else {
                System.out.print("Invalid placement (Outside of Range). Please enter a valid placement: ");
            }
        }
        return placement;
    }

    private static int validPosition(ArrayList<Integer> positions, int numOfPlayers) {
        int position;
        System.out.print("Enter the position (turn order of the final Jeopardy) of the player: ");
        while (true) {
            position = validIntInput();
            if (position == -1) System.exit(1);
            if (position > 0 && position <= numOfPlayers) {
                if (!positions.contains(position)) {
                    break;
                }
                else {
                    System.out.print("Position has already been used. Please enter a different position: ");
                }
            }
            else {
                System.out.print("Invalid position (Outside of Range). Please enter a valid position: ");
            }
        }
        return position;
    }
}
