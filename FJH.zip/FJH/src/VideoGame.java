public class VideoGame {
    private String name;
    private String releaseYear;

    public VideoGame(String name, String releaseYear) {
        this.name = name;
        this.releaseYear = releaseYear;
    }

    //setters

    public void setName (String name) {
        this.name = name;
    }

    public void setReleaseYear (String releaseYear) {
        this.releaseYear = releaseYear;
    }

    //getters

    public String getName() {
        return this.name;
    }

    public String getReleaseYear() {
        return this.releaseYear;
    }

    //to String

    public String toString() {
        return "Name: " + this.name + "\n" + "ReleaseYear: " + this.releaseYear;
    }
}
